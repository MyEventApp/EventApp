const path = require('path');

var config = {
   entry: __dirname + '/src',
   output: {
    path: path.resolve(__dirname, "src"),
    filename: 'bundle.js',
   },
   devtool: 'source-map',
  //  devServer: {
  //     inline: true,
  //     port: 5050
  //  },

   module: {
      loaders: [
         {
            test: /\.jsx?$/,
            exclude: /node_modules/,
            loader: 'babel-loader',

            query: {
               presets: ['es2015', 'react','stage-0']
            }
         },
         {
           test: /\.(jpe?g|png|gif|svg)$/i,
           loader: "file-loader?name=../public/icons/[name].[ext]"
         },
         {test: /\.css$/, loader: 'style-loader!css-loader'}
      ]
   }
}

module.exports = config;

import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Route} from 'react-router-dom';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import HomePage from './views/HomePage';
import EventsPage from './views/EventsPage';
import AgendaPage from './views/AgendaPage';
import MyEventsPage from './views/MyEventsPage';
import AgendaDetailsPage from './views/AgendaDetailsPage';
import ContactPage from './views/ContactPage';
import InviteePage from './views/InviteePage';
import GalleryPage from './views/GalleryPage';
import MySchedulePage from './views/MySchedulePage';
import SponsorListPage from './views/SponsorListPage';
import ProfilePage from './views/ProfilePage';
import SpeakersPage from './views/SpeakersPage';
import AttendeesPage from './views/AttendeesPage';
import CreateEventtPage from './views/CreateEventtPage';
import PastEventsPage from './views/PastEventsPage';
import SponsorDetailsPage from './views/SponsorDetailsPage';
import AcceptedEventsPage from './views/AcceptedEventsPage';
import DeclinedInvitesPage from './views/DeclinedInvitesPage';
import InvitesPage from './views/InvitesPage';
import CreditsPage from './views/CreditsPage';
import DemoEventPage from './views/DemoEventPage';
import LoginPage from './views/LoginPage';
import SignUpPage from './views/SignUpPage';
import MainPage from './views/MainPage';
import NotificationsPage from './views/NotificationsPage';
import './css/style.css';
import Flex from '../node_modules/flexboxgrid/css/flexboxgrid.css';

class App extends React.Component{
 render(){
   return(<div>
     <MuiThemeProvider>
     <BrowserRouter>
       <div>
         <Route exact path='/' component={MainPage}/>
         <Route exact path='/login' component={LoginPage}/>
         <Route path='/signup' component={SignUpPage}/>
         <Route path='/home' component={HomePage}/>
         <Route path='/demoevent' component={DemoEventPage}/>
         <Route path='/details/:value' component={EventsPage}/>
         <Route path='/agendalist/:value' component={AgendaPage}/>
         <Route path='/myevents' component={MyEventsPage}/>
         <Route path='/agendadetails/:value' component={AgendaDetailsPage}/>
         <Route path='/contact/:value' component={ContactPage}/>
         <Route path='/inviteelist/:value' component={InviteePage}/>
         <Route path='/gallery' component={GalleryPage}/>
         <Route path='/schedule' component={MySchedulePage}/>
         <Route path='/sponsorlist/:value' component={SponsorListPage}/>
         <Route path='/profile' component={ProfilePage}/>
         <Route path='/speakers/:value' component={SpeakersPage}/>
         <Route path='/attendees' component={AttendeesPage}/>
         <Route path='/createevent' component={CreateEventtPage}/>
         <Route path='/pastevents' component={PastEventsPage}/>
         <Route path='/sponsordetails/:value' component={SponsorDetailsPage}/>
         <Route path='/accepted/:value' component={AcceptedEventsPage}/>
         <Route path='/declinedinvites/:value' component={DeclinedInvitesPage}/>
         <Route path='/invites/:value' component={InvitesPage}/>
         <Route path='/credits' component={CreditsPage}/>
         <Route path='/notifications' component={NotificationsPage}/>
         </div>
         </BrowserRouter>
      </MuiThemeProvider>
   </div>)
 }
};
ReactDOM.render(<App />
, document.getElementById('root'));

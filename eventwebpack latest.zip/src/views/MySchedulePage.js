import React from 'react';
import Layout from '../components/Layout';
import {MySchedule,MyScheduleData} from '../components/MySchedule';
import $ from 'jquery';

class MySchedulePage extends React.Component{
    state={
            scheduleData:[]
        };

        getData = () => {
            $.ajax({
                url:'/schedule',
                type:'GET',
                dataType:'json',

                success:function(data)
                {
                    console.log('data from server to schedulepage');
                    this.setState({scheduleData:data.DbData});
                    console.log(data);
                }.bind(this)
            });
        }
        componentWillMount = () =>{
            this.getData();
        }


    render(){
        return(
     <div>
            <MyScheduleData scheduleData={this.state.scheduleData}/>
            <Layout/>
            </div>
            );
    }
};

export default MySchedulePage;

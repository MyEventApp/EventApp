import React from 'react';
import Layout from '../components/Layout';
import {CreatedEventData,MyEvents} from '../components/MyEvents';
import $ from 'jquery';

class MyEventsPage extends React.Component{
	state={
			eventData:[]
		};

		getData = () => {
			$.ajax({
				url:'/adminevents',
				type:'GET',
				dataType:'json',
				success:function(data)
				{
					console.log('data from server to myevents page');
					this.setState({eventData:data.DbData});
					console.log(data);
				}.bind(this)
			});
		}
		componentWillMount = () =>{
			this.getData();
		}
	render(){
		return(
      <div>
			<CreatedEventData eventData={this.state.eventData}/>
			<Layout/>
			</div>
			);
	}
};

export default MyEventsPage;

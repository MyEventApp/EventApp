import React from 'react';
import Layout from '../components/Layout';
import AgendaDetails from '../components/AgendaDetails';
import $ from 'jquery';

class AgendaDetailsPage extends React.Component{
	state={
			agendaDetail:[]
		};

		getData = () => {
			// $.ajax({
			// 	url:'/agendaDetail/'+this.props.match.params.value,
			// 	type:'GET',
			// 	dataType:'json',
			//
			// 	success:function(data)
			// 	{
			// 		console.log('data from server to agendapage');
			// 		this.setState({agendaDetail:data.DbData});
			// 		console.log(data);
			// 	}.bind(this)
			// });
			var sessionAgendaDetail=[];
			var agendaId= this.props.match.params.value;
			sessionAgendaDetail = JSON.parse(sessionStorage.agenda);
			console.log(sessionAgendaDetail.length);
			for(var i=0;i<sessionAgendaDetail.length;)
			{
				console.log(JSON.stringify(sessionAgendaDetail[i]));
				sessionStorage.AgendaId = JSON.stringify(sessionAgendaDetail[i].AgendaId);
				var id=JSON.parse(sessionStorage.AgendaId);
				console.log(id);
				if(agendaId==id){
					console.log('hiii');
					this.setState({agendaDetail:sessionAgendaDetail[i]});
					break;
				}
				console.log(JSON.stringify(sessionAgendaDetail[i]));
				i=i+1;
		}
		}
		componentWillMount = () =>{
			this.getData();
		}

	render(){
		return(
      <div>
			<AgendaDetails agendaDetail={this.state.agendaDetail} />
			<Layout/>
			</div>
			);
	}
};

export default AgendaDetailsPage;

import React from 'react';
import Layout from '../components/Layout';
import AcceptedEvents from '../components/AcceptedEvents';

class AcceptedEventsPage extends React.Component{

	render(){
		return(
      <div>
			<AcceptedEvents />
			<Layout/>
			</div>
			);
	}
};

export default AcceptedEventsPage;

import React from 'react';
import Layout from '../components/Layout';
import {Speakers,SpeakersList} from '../components/Speakers';
import $ from 'jquery';

class SpeakersPage extends React.Component{
	state={
			speakerList:[],
			speakers:[]
		};

		getData = () => {
			// if(speakers.length<0){
			// 	$.ajax({
			// 		url:'/speakers/'+this.props.match.params.value,
			// 		type:'GET',
			// 		dataType:'json',
			//
			// 		success:function(data)
			// 		{
			// 			console.log('data from server to speakerpage');
			// 			sessionStorage.speakers=JSON.stringify(data.DbData);
			 		 	var sessionSpeakers= JSON.parse(sessionStorage.speakers);
			// 			this.setState({speakerList:sessionSpeakers});
			// 			console.log(data);
			// 		}.bind(this)
			// 	});
			// }
			// else{
			this.setState({speakerList: sessionSpeakers});
		}
		componentWillMount = () =>{
			this.getData();
		}
	render(){
		return(
      <div>
			<SpeakersList speakerList={this.state.speakerList} />
			<Layout/>
			</div>
			);
	}
};

export default SpeakersPage;

import React from 'react';
import Layout from '../components/Layout';
import {Contact,ContactPersonData} from '../components/Contact';
import $ from 'jquery';

class ContactPage extends React.Component{
	state={
			contactPerson:[]
		};

		getData = () => {
			$.ajax({
				url:'http://localhost:5050/contactperson/'+this.props.match.params.value,
				type:'GET',
				dataType:'json',

				success:function(data)
				{
					console.log('data from server to contactPerson Page');
					this.setState({contactPerson:data.DbData});
					console.log(data);
				}.bind(this)
			});
		}
		componentWillMount = () =>{
			this.getData();
		}
	render(){
		return(
      <div>
			<ContactPersonData contactPerson={this.state.contactPerson} />
			<Layout/>
			</div>
			);
	}
};


export default ContactPage;

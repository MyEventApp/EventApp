import React from 'react';
import Layout from '../components/Layout';
import Notifications from '../components/Notifications';
import $ from 'jquery';
var x ='';
class NotificationsPage extends React.Component{
	state={
			notifications:[],
		};

		getData = () => {
			$.ajax({
				url:'/notifications',
				type:'GET',
				dataType:'json',
				success:function(data)
				{
					console.log('data from server to notifications page');
					this.setState({notifications:data.DbData});
					console.log(data);
				}.bind(this)
			});
		}
		componentWillMount = () =>{
			this.getData();
		}
	render(){
		return(
      <div>
			<Notifications notifications={this.state.notifications}/>
			<Layout/>
			</div>
			);
	}
};

export default NotificationsPage;

import React from 'react';
import Login from '../components/Login';

class LoginPage extends React.Component{

	render(){
		return(
      <div>
			<Login />
			</div>
			);
	}
};

export default LoginPage;

import React from 'react';
import Layout from '../components/Layout';
import PastEvent from '../components/PastEvent';

class PastEventsPage extends React.Component{

	render(){
		return(
      <div>
			<PastEvent />
			<Layout/>
			</div>
			);
	}
};

export default PastEventsPage;

import React from 'react';
import Layout from '../components/Layout';
import {Invites,InviteeData} from '../components/Invites';
import $ from 'jquery';

class InvitesPage extends React.Component{
	state={
			inviteeDetails:[]
		};
	getData = () => {
		$.ajax({
			url:'/inviteeList/'+this.props.match.params.value,
			type:'GET',
			dataType:'json',

			success:function(data)
			{
				console.log('data from server to AllInvitesPage page');
				this.setState({inviteeDetails:data.DbData});
				console.log(data);
			}.bind(this)
		});
	}
	componentWillMount = () =>{
		this.getData();
	}

	render(){
		return(
      <div>
			<InviteeData inviteeDetails={this.state.inviteeDetails} />
			<Layout/>
			</div>
			);
	}
};

export default InvitesPage;

import React from 'react';
import Main from '../components/Main';

class MainPage extends React.Component{

	render(){
		return(
      <div>
			<Main />
			</div>
			);
	}
};

export default MainPage;

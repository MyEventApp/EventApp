import React from 'react';
import Layout from '../components/Layout';
import {InviteeListData} from '../components/AcceptedInviteeList';
import $ from 'jquery';

class InviteePage extends React.Component{
	state={
			acceptedInviteeDetails:[]
		};
	getData = () => {
		$.ajax({
			url:'/acceptedInviteeList/'+this.props.match.params.value,
			type:'GET',
			dataType:'json',
			success:function(data)
			{
				console.log('data from server to InviteePage page');
				this.setState({	acceptedInviteeDetails:data.DbData});
				console.log(data);
			}.bind(this)
		});
	}
	componentWillMount = () =>{
		this.getData();
	}
	render(){
		console.log(this.props.match.params.value);
		return(
      <div>
			<InviteeListData acceptedInviteeDetails={this.state.acceptedInviteeDetails} />
			<Layout/>
			</div>
			);
	}
};
export default InviteePage;

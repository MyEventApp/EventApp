import React from 'react';
import Layout from '../components/Layout';
import DemoEvent from '../components/DemoEvent';
import $ from 'jquery';

class DemoEventPage extends React.Component{
	// state={
	// 		eventData:[]
	// 	};
	//
	// 	getData = () => {
	// 		$.ajax({
	// 			url:'/events',
	// 			type:'GET',
	// 			dataType:'json',
	// 			success:function(data)
	// 			{
	// 				console.log('data from server to home page');
	// 				this.setState({eventData:data.DbData});
	// 				console.log(data);
	// 			}.bind(this)
	// 		});
	// 	}
	// 	componentWillMount = () =>{
	// 		this.getData();
	// 	}

	render(){
		return(
      <div>
			<DemoEvent/>
			<Layout/>
			</div>
			);
	}
};

export default DemoEventPage;

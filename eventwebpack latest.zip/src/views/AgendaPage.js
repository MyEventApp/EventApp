import React from 'react';
import Layout from '../components/Layout';
import {AgendaData,AgendaList} from '../components/AgendaList';
import $ from 'jquery';

class AgendaPage extends React.Component{
	state={
			agendaList:[],
			speakerList:[]
		};

		getData = () => {
			$.ajax({
				url:'http://localhost:5050/agendaList/'+this.props.match.params.value,
				type:'GET',
				dataType:'json',
				success:function(data)
				{
					console.log('data from server to agendapage');
					sessionStorage.agenda=JSON.stringify(data.DbData);
					var sessionAgenda= JSON.parse(sessionStorage.agenda);
					console.log(sessionAgenda);
					this.setState({agendaList:sessionAgenda});

					$.ajax({
						url:'/speakers/'+this.props.match.params.value,
						type:'GET',
						dataType:'json',

						success:function(data)
						{
							console.log('data from server to speakerpage');
							sessionStorage.speakers=JSON.stringify(data.DbData);
						 	var sessionSpeakers= JSON.parse(sessionStorage.speakers);
							this.setState({speakerList:sessionSpeakers});
							console.log(data);
						}.bind(this)
					});
				}.bind(this)
			});
		}
		componentWillMount = () =>{
			this.getData();
		}

	render(){
		return(
      <div>
			<AgendaData agendaList={this.state.agendaList} speakerList={this.state.speakerList} />
			<Layout/>
			</div>
			);
	}
};

export default AgendaPage;

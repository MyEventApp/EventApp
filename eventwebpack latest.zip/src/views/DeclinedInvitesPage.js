import React from 'react';
import Layout from '../components/Layout';
import {DeclinedInvitesData} from '../components/DeclinedInvites';
import $ from 'jquery';

class DeclinedInvitesPage extends React.Component{
	state={
			declinedInviteeDetails:[]
		};
	getData = () => {
		$.ajax({
			url:'/declinedInviteeList/'+this.props.match.params.value,
			type:'GET',
			dataType:'json',

			success:function(data)
			{
				console.log('data from server to DeclinedInviteePage page');
				this.setState({	declinedInviteeDetails:data.DbData});
				console.log(data);
			}.bind(this)
		});
	}
	componentWillMount = () =>{
		this.getData();
	}

	render(){
		return(
      <div>
			<DeclinedInvitesData declinedInviteeData={this.state.declinedInviteeDetails}/>
			<Layout/>
			</div>
			);
	}
};

export default DeclinedInvitesPage;

import React from 'react';
import Layout from '../components/Layout';
import {SponsorData, SponsorList} from '../components/SponsorList';
import $ from 'jquery';

class SponsorListPage extends React.Component{
	state={
			sponsorList:[]
		};

		getData = () => {
			$.ajax({
				url:'/sponsors/'+this.props.match.params.value,
				type:'GET',
				dataType:'json',

				success:function(data)
				{
					console.log('data from server to speakerpage');
					this.setState({sponsorList:data.DbData});
					console.log(data);
				}.bind(this)
			});
		}
		componentWillMount = () =>{
			this.getData();
		}
	render(){
		return(
      <div>
			<SponsorData sponsorList={this.state.sponsorList} />
			<Layout/>
			</div>
			);
	}
};

export default SponsorListPage;

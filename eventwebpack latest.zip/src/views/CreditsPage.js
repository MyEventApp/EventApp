import React from 'react';
import Layout from '../components/Layout';
import Credits from '../components/Credits';

class CreditsPage extends React.Component{

	render(){
		return(
      <div>
			<Credits />
			<Layout/>
			</div>
			);
	}
};

export default CreditsPage;

import React from 'react';
import Layout from '../components/Layout';
import {SponsorDetails,SponsorDetailsData} from '../components/SponsorDetails';
import $ from 'jquery';

class SponsorDetailsPage extends React.Component{

	state={
			sponsorDetails:[]
		};

		getData = () => {
			$.ajax({
				url:'/sponsordetails/'+this.props.match.params.value,
				type:'GET',
				dataType:'json',

				success:function(data)
				{
					console.log('data from server to sponsorspage page');
					this.setState({sponsorDetails:data.DbData});
					console.log(data);
				}.bind(this)
			});
		}
		componentWillMount = () =>{
			this.getData();
		}

	render(){
		return(
      <div>
			<SponsorDetailsData sponsorDetails={this.state.sponsorDetails} />
			<Layout/>
			</div>
			);
	}
};

export default SponsorDetailsPage;

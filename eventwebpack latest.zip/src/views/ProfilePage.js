import React from 'react';
import Layout from '../components/Layout';
import {ProfileData,Profile} from '../components/Profile';
import $ from 'jquery';

class ProfilePage extends React.Component{
	state={
			profileData:[]
		};

		getData = () => {
			$.ajax({
				url:'/profile',
				type:'GET',
				dataType:'json',

				success:function(data)
				{
					console.log('data from server to eventspage page');
					this.setState({profileData:data.DbData});
					console.log(data);
				}.bind(this)
			});
		}
		componentWillMount = () =>{
			this.getData();
		}

	render(){
		return(
      <div>
			<ProfileData profileData={this.state.profileData}/>
			<Layout/>
			</div>
			);
	}
};

export default ProfilePage;

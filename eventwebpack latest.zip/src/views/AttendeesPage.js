import React from 'react';
import Layout from '../components/Layout';
import Attendees from '../components/Attendees';

class AttendeesPage extends React.Component{

	render(){
		return(
      <div>
			<Attendees />
			<Layout/>
			</div>
			);
	}
};

export default AttendeesPage;

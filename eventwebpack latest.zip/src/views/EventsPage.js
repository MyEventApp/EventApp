import React from 'react';
import Layout from '../components/Layout';
import EventDetails from '../components/EventDetails';
import $ from 'jquery';

class EventsPage extends React.Component{
	state={
			eventDetails:[]
		};

		getData = () => {
			// $.ajax({
			// 	url:'/events/'+this.props.match.params.value,
			// 	type:'GET',
			// 	dataType:'json',
			//
			// 	success:function(data)
			// 	{
			// 		console.log('data from server to eventspage page');
			// 		this.setState({eventDetails:data.DbData});
			// 		console.log(data);
			// 	}.bind(this)
			// });

			var sessionEventDetail=[];
			var eventId= this.props.match.params.value;
			sessionEventDetail = JSON.parse(sessionStorage.events);
			console.log(sessionEventDetail.length);
			for(var i=0;i<sessionEventDetail.length;)
			{
				console.log(JSON.stringify(sessionEventDetail[i]));
				sessionStorage.Id = JSON.stringify(sessionEventDetail[i].EventId);
				var id=JSON.parse(sessionStorage.Id);
				console.log(id);
				if(eventId==id){
					console.log('hiii');
					this.setState({eventDetails:sessionEventDetail[i]});
					break;
				}
				else{
					console.log('else');
				}
				console.log(JSON.stringify(sessionEventDetail[i]));
				i=i+1;
		}
	}
		componentWillMount = () =>{
			this.getData();
		}

	render(){
		console.log(this.props.match.params.value);
		return(
      <div>
			<EventDetails eventDetails={this.state.eventDetails}/>
			<Layout/>
			</div>

			);
	}
};

export default EventsPage;

import React from 'react';
import Layout from '../components/Layout';
import LandingPage from '../components/LandingPage';
import $ from 'jquery';
var sessionEvents=[];
var eventId=[];


class HomePage extends React.Component{
	state={
			eventData:[]
		};

		getData = () => {
			$.ajax({
				url:'/events',
			type:'GET',
			dataType:'json',
			success:function(data)
			{
				console.log('data from server to home page');
				console.log(data);
				sessionStorage.events=JSON.stringify(data.DbData);
				sessionEvents= JSON.parse(sessionStorage.events);
				console.log(sessionEvents);
				this.setState({eventData:sessionEvents});
			}.bind(this)
			});
		}
		componentWillMount = () =>{
				this.getData();


		}

	render(){

		return(
      <div>
			<LandingPage eventData={this.state.eventData} />
			<Layout/>
			</div>
			);
	}
};

export default HomePage;

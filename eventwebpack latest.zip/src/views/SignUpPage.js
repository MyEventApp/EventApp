import React from 'react';
import Layout from '../components/Layout';
import SignUp from '../components/SignUp';

class SignUpPage extends React.Component{

	render(){
		return(
      <div>
			<SignUp />
			</div>
			);
	}
};

export default SignUpPage;

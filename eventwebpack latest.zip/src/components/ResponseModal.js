import React, { Component} from 'react';
import { Button,Form,FormGroup,FormControl,Col,ControlLabel } from 'react-bootstrap';
import {Link} from 'react-router-dom';
import Paper from 'material-ui/Paper';


const styles = {
  paper:{
    background:'#E0E0E0 ',
    height: '100%',
    width: '100%',
    border:'1px solid',
    borderRadius: '13px',
    borderColor:'#BDC3C7 ',
  },
  FormGroup:{
   margin: '0px',
   marginTop: '10px',
   marginBottom: '10px'
  },
 button:{
   background: '#FFD84A ',
   marginRight: '5px',
 },
};

class ResponseModal extends Component {

 render() {
  return (
<div>
<Paper style={styles.paper}>
<Form horizontal style={{fontSize:'10px'}}>
<FormGroup controlId="formHorizontalEmail" bsSize='small' style={styles.FormGroup}>
 <Col componentClass={ControlLabel} xs={4}>
   RSVP Status
 </Col>
 <Col xs={8}>
 <select style={{width:'100%',height:'30px'}} id="rsvpStatus">
   <option value="Your Choice" selected="selected">Select Response</option>
   <option value="accept">Accept</option>
   <option value="decline">Decline</option>
    <option value="tentative">Tentative</option>
 </select> </Col>
</FormGroup>
<FormGroup bsSize='small' style={styles.FormGroup}>
 <Col componentClass={ControlLabel} xs={4}>
  Cost Center
 </Col>
 <Col xs={8}>
   <FormControl type="text" placeholder="e.g WT123" id="costCenter"/>
 </Col>
</FormGroup>
<FormGroup bsSize='small' style={styles.FormGroup}>
 <Col componentClass={ControlLabel} xs={4}>
   Food Preference
 </Col>
 <Col xs={8}>
 <select style={{width:'100%',height:'30px'}} id="food">
   <option value="Your Choice">Select Your Meal</option>
   <option value="veg">Veg</option>
   <option value="non-veg">Non-Veg</option>
 </select>
 </Col>
</FormGroup>
<FormGroup bsSize='small' style={styles.FormGroup}>
 <Col componentClass={ControlLabel} xs={4}>
   Transport Details
 </Col>
 <Col xs={8}>
   <FormControl type="text" placeholder="e.g Cab, Bus" id="transport"/>
 </Col>
</FormGroup>
</Form>
</Paper>
</div>
);
}
}
export default ResponseModal;

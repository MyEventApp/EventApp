import React, { Component} from 'react';
import {Link} from 'react-router-dom';
import Paper from 'material-ui/Paper';
import TextField from 'material-ui/TextField';
import Avatar from 'material-ui/Avatar';
import img1 from '../images/download1.jpg';
import backbutton from '../images/back-button.png';
import Edit from 'material-ui/svg-icons/image/edit';
import '../css/style.css';

const styles={

profilepaper:{
    background:'#424242 ',
     height: '100%',
     marginBottom:'2px',
},
paper1:{
    background:'#FFD93A ',
    height:'100%',
    border:'1px solid',
    borderColor:'#BDC3C7 ',
    borderRadius:'7px'

},
paper:{
    height: '100%',
    border:'1px solid',
    marginBottom:'2px',
    borderColor:'#BDC3C7 ',
    borderRadius:'7px'

  },
  content:{
    marginLeft:'6px',
  },
  time:{
    marginTop:"31px"
  },
  name:{
    color:'#FFFFFF '
  },
  floatingLabelFocusStyle:{
    color:'#FFD93A '
  },
  underlineFocusStyle:{
    borderColor:'#FFD93A '
  }
  };

  export class ProfileData extends Component {
  render() {

    console.log(this.props.profileData);

    var profileData = this.props.profileData.map(function(data) {
          return (
            <Profile key={data.ProfileId} FirstName={data.FirstName} LastName={data.LastName} Occupation={data.Occupation} Department={data.Department}
            MobileNumber={data.MobileNumber} Email={data.Email} City={data.City} State={data.State} Country={data.Country} AdId={data.AdId}/>
          );
        }.bind(this));
    return(
     <div className='col-xs-12 section'>
     {profileData}
     </div>
    );
  }
}


export class Profile extends Component  {
  constructor(props) {
    super(props);
    this.state = {disabled:true,disabled1:true};
  };

   handleClick= () =>{
     this.setState({disabled:false});
   };
   handleClick1= () =>{
     this.setState({disabled1:false});
   };

 render() {
return(
 <div>
 <Paper zDepth={1} rounded={true} style={styles.profilepaper} >
 <div className='row'>
 <div className='col-xs-2'>
 <Link to='/demoevent'>
 <p><img src={backbutton} style={{width:'70%',marginTop:"5px"}}/></p>
 </Link>
 </div>
 <div className='col-xs-8'>
 <center><h4 style={styles.name}><b>Profile</b></h4></center>
 </div>
 </div>

 <div className='row'>
 <div className='col-xs-12'>
 <center>
 <Avatar src={img1} size={150}/>
 </center>
 </div>
 </div>

 <div className='row'>
 <div className='col-xs-12'>
 <center>
 <p style={styles.name}><strong>{this.props.FirstName} {this.props.LastName}</strong></p>
 <p style={styles.name}>{this.props.Department}</p>
 </center>
 </div>
 </div>
 </Paper>

 <div className='row'>
 <div className='col-xs-12'>
 <Paper zDepth={2} rounded={true} style={{borderRadius:"7px"}}>
 <h5 style={{background:'#FFD93A ', borderRadius:'6px', padding:'6px'}}><strong>About</strong><Edit id="edit1" style={{float:'right',padding:'2px',marginTop:'-5px'}} onClick={this.handleClick1}/></h5>
 <div style={{margin:'6px'}}>
 <TextField defaultValue={this.props.Email}  floatingLabelText="Email" disabled={this.state.disabled1} fullWidth={true} underlineFocusStyle={styles.underlineFocusStyle}
     floatingLabelFocusStyle={styles.floatingLabelFocusStyle} style={{fontSize:'14px'}}/>
<TextField defaultValue={this.props.AdId}  floatingLabelText="AD ID" disabled={this.state.disabled1} fullWidth={true} style={{fontSize:'14px'}} underlineFocusStyle={styles.underlineFocusStyle}
     floatingLabelFocusStyle={styles.floatingLabelFocusStyle} />
<TextField defaultValue={this.props.MobileNumber}  floatingLabelText="Phone No." disabled={this.state.disabled1} fullWidth={true} style={{fontSize:'14px'}} underlineFocusStyle={styles.underlineFocusStyle}
     floatingLabelFocusStyle={styles.floatingLabelFocusStyle} />
 </div>
 </Paper>
 </div>
 </div>

 <div className='row'>
 <div className='col-xs-12'>
 <Paper zDepth={2} rounded={true} style={{borderRadius:"7px"}}>
 <h5 style={{background:'#FFD93A ', borderRadius:'6px', padding:'6px'}}><strong>Address</strong><Edit id="edit" style={{float:'right',padding:'2px',marginTop:'-5px'}} onClick={this.handleClick}/></h5>
 <div style={{margin:'6px'}}>
 <TextField defaultValue={this.props.City}  floatingLabelText="City" disabled={this.state.disabled} fullWidth={true} style={{fontSize:'14px',fontColor:'black'}} underlineFocusStyle={styles.underlineFocusStyle}
       floatingLabelFocusStyle={styles.floatingLabelFocusStyle} />
  <TextField defaultValue={this.props.State}  floatingLabelText="State" disabled={this.state.disabled} fullWidth={true} style={{fontSize:'14px'}} underlineFocusStyle={styles.underlineFocusStyle}
       floatingLabelFocusStyle={styles.floatingLabelFocusStyle} />
  <TextField defaultValue={this.props.Country} floatingLabelText="Country" disabled={this.state.disabled} fullWidth={true} style={{fontSize:'14px'}} underlineFocusStyle={styles.underlineFocusStyle}
       floatingLabelFocusStyle={styles.floatingLabelFocusStyle} />
 </div>
 </Paper>
 </div>
 </div>
</div>
);
}
}

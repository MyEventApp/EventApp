import React, { Component,PropTypes} from 'react';
import {Link,Redirect} from 'react-router-dom';
import Paper from 'material-ui/Paper';
import { Button, Form,FormGroup,FormControl,Col,ControlLabel } from 'react-bootstrap';
import SignUp from './SignUp';
import '../css/style.css';
import $ from 'jquery';

const styles={
 paper:{
     background: '#FFD93A ',
     height: '100%',
     border:'1px solid',
     marginBottom:'11px',
     borderColor:'#BDC3C7 ',
   },
 };

class Login extends Component  {

  constructor(props) {
    super(props);
    this.state = { loginData :[],
    data1: [],
    obj1: [],
    redirect: false
  };}

  handleClick = () => {
    let x ={
    LoginId: document.getElementById('loginId').value,
    Password: document.getElementById('password').value
   };
    console.log(x.LoginId);

    $.ajax({
      url:'/login',
      type:'GET',
      dataType:'json',
      success:function(data)
      {
        console.log('data from server to home page');

        this.setState({loginData :data.DbData});
        var obj = this.state.loginData;
        var i= 0;
        for(i=0; i<obj.length; i++){
          let a = this.state.obj1;
          a[i] = obj[i];
          this.setState({obj1 :a});
          sessionStorage.keyname=JSON.stringify((this.state.obj1)[i]);
          var tvalue = JSON.parse(sessionStorage.keyname);
        console.log(tvalue);
        console.log(Object.values((this.state.obj1)[i])[2]);

          if((Object.values((this.state.obj1)[i])[2]==x.LoginId) && (Object.values((this.state.obj1)[i])[0]==x.Password))
          {
            $.ajax({
              url:'/loginid',
              type:'GET',
              dataType:'json',
              data: x,
              success:function(data)
              {
                console.log('data');
                console.log(data);
              }.bind(this),
              error:function(err){
                console.log(err);
              }.bind(this)
            });
               this.setState({redirect: true});
            break;
          }
          else{
              this.setState({redirect: false});

          }
}
    var temp = this.state.redirect;
    if(!temp){
        alert('Username or Password not valid');

    }}.bind(this)
        });
}
render() {
  if (this.state.redirect==true) {
    return <Redirect push to="/home" />;
  }
return (<center>
 <div className='col-xs-12' style={{marginTop:'160px'}}>
 <Paper style={styles.paper}>
 <h4>Login</h4>
 <Form horizontal style={{fontSize: '12px'}} onSubmit={this.handleClick}>
 <FormGroup bsSize='small' style={{margin:'0px',marginTop:'10px',marginBottom:'10px'}}>
   <Col componentClass={ControlLabel} xs={4}>
    Username
   </Col>
   <Col xs={8}>
     <FormControl type="text" id="loginId" />
   </Col>
 </FormGroup>
 <FormGroup bsSize='small' style={{margin:'0px',marginTop:'10px',marginBottom:'10px'}}>
   <Col componentClass={ControlLabel} xs={4}>
    Password
   </Col>
   <Col xs={8}>
     <FormControl type="password" id="password" />
   </Col>
 </FormGroup>
 <FormGroup bsSize='small' style={{margin:'0px',marginTop:'10px',marginBottom:'10px'}}>
   <Col componentClass={ControlLabel} xs={6}>
  New User?<Link to='/signup'>Sign Up</Link>
   </Col>
   <Col xs={6}>
  <Button bsSize='xs' style={{float:'right'}} onClick={this.handleClick} >Submit</Button>
  </Col>
 </FormGroup>
 </Form>
 </Paper>
 </div></center>
)}
};

export default Login;

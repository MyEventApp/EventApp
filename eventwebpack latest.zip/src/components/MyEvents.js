import React, { Component} from 'react';
import { Button,Form,FormGroup,FormControl,Col,ControlLabel } from 'react-bootstrap';
import {Link} from 'react-router-dom';
import {Card,CardHeader, CardText} from 'material-ui/Card';
import Dialog from 'material-ui/Dialog';
import backbutton from '../images/back-button.png';
import Modal from './Modal';

const styles = {
  button:{
    background: '#FFD84A',
    marginRight: '5px',
  },
  sendbutton:{
    background: '#FFD84A',
    marginLeft: '5px',
  },
  card:{
    padding:'8px',
    border:'1px solid',
    marginTop:'7px',
    borderRadius: '7px',
    borderColor:'#BDC4C7',
    background:'#FFD84A',
  },
};
export class CreatedEventData extends Component {
  render(){
    var createdEventData = this.props.eventData.map(function(data) {
          return (
            <MyEvents key={data.EventId}
            EventName={data.EventName}
            EventId={data.EventId} />
          );
        }.bind(this));

  return(
    <div className='col-xs-12 section'>
 <div className='row'>
 <div className='col-xs-2'>
 <Link to='/home'>
 <p><img src={backbutton} style={{width:'70%',marginTop:"5px"}}/></p>
 </Link>
 </div>
 <div className='col-xs-8'>
 <center><h4><b>My Events</b></h4></center>
 </div></div>
 <div className='row' >
   <div className='col-xs-6'>
   <Link to='/accepted'>
     <Button block active id="button1" bsSize='small' onClick={this.handleChange}>Accepted</Button>
   </Link>
   </div>
   <div className='col-xs-6'>
     <Button block active id="button2" bsSize='small' style={styles.button} onClick={this.handleChange1}>Created</Button>
   </div>
 </div>
 {createdEventData}</div>
  )
  }
}
export class MyEvents extends Component {
  constructor(props) {
    super(props);
    this.state = {open: false};
  };

  handleOpen = () => this.setState({open: true});

  handleClose = () => this.setState({open: false});

  handleChange = () => {
  document.getElementById("button1").style.backgroundColor="#FFD93A";
  document.getElementById("button2").style.backgroundColor="#E0E0E0";
};

  handleChange1 = () => {
  document.getElementById("button1").style.backgroundColor="#E0E0E0";
  document.getElementById("button2").style.backgroundColor="#FFD93A";
};

  render() {
    sessionStorage.CreateEventId = JSON.stringify(this.props.EventId);
    console.log(JSON.parse(sessionStorage.CreateEventId));
    const actions = [
      <Button active bsSize='small'onTouchTap={this.handleClose}>Cancel</Button>,
      <Button active bsSize='small' style={styles.sendbutton} >Send</Button>]
   return (
  <div>
  <Card style={{borderRadius:'7px'}}>
    <CardHeader title={this.props.EventName} actAsExpander={true} showExpandableButton={true} style={styles.card} />
    <CardText expandable={true}  style={{color:'#424242',fontSize:'83%',marginLeft:'-10px'}}>
      <div className='col-xs-4'><center><Link to='/createevent'>Update Event</Link></center></div>
      <div className='col-xs-4'><center> <Link to={'/inviteelist/'+this.props.EventId}>Invitee List</Link></center></div>
      <div className='col-xs-4'><center>Announcements</center></div>
    </CardText>
  </Card>
  </div>
);
}
}

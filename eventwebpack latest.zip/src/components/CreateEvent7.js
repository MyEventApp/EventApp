import React from 'react';
import Dropzone from 'react-dropzone';
import {Collapse} from 'react-collapse';
import Paper from 'material-ui/Paper';
import backbutton from '../images/back-button.png';
import {Button} from 'react-bootstrap';
import { Form,FormGroup,FormControl,Col,ControlLabel } from 'react-bootstrap';
import {SponsorList} from './List.js';
import $ from 'jquery';
let dropzoneRef;

const styles = {
  paper:{
    background:'#E0E0E0',
    height: '100%',
    width: '100%',
    border:'1px solid',
    marginTop:'11px',
    marginBottom:'11px',
    borderRadius: '13px',
    borderColor:'#BDC3C7',
  },
  heading:{
    marginLeft: '25px',
  },

  headline: {
    fontSize: 24,
    paddingTop: 16,
    marginBottom: 12,
    fontWeight: 400,
  },
  addbutton:{
    marginRight:'10px',
    float:'right'
  },
  FormGroup:{
   margin: '0px',
   marginTop: '10px',
   marginBottom: '10px'
  },
  button1:{
    background: '#FFD93A ',
    float:'right'
  },
};

var addmore ={};

export default class CreateEvent7 extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      slideIndex:0,
      open: true,
      accepted: [],
      agendaName: [],
      items : [],
      sponsorName: '',
      companyLogo: '',
      emailId: '',
      contact: '',
      description: '',
      websiteUrl: '',
      id : 0,
      check:true
     };
  }

  onDrop(files) {
    this.setState({
      files
    });
  };

  handleClick = () => {
    const {slideIndex} = this.state;
    if(slideIndex<7){
    this.setState({
      slideIndex: slideIndex+1,
    });};
  };

  handleSubmit =(e) => {

    addmore[this.state.sponsorName]=this.state.companyLogo;
    e.preventDefault();
    console.log("allow");

    this.setState({id:this.state.id+1});
    console.log("state id value is =" + this.state.id);

    var nextItems = this.state.items.concat({sponsorName: this.state.sponsorName,
                                                companyLogo: this.state.companyLogo,
                                                emailId: this.state.emailId,
                                                contact: this.state.contact,
                                                description: this.state.description,
                                                websiteUrl: this.state.websiteUrl,
                                                id:this.state.id}
                                              );
                                              console.log("nextitems = "+ nextItems.agendaName);
      var nextText = '';
      this.setState({items: nextItems, sponsorName: nextText, companyLogo: nextText, emailId: nextText, contact: nextText, description: nextText, websiteUrl: nextText});

  console.log("all data =" +  this.state.items);
  };

  onChangeSponsorName =(e) => {
      this.setState({sponsorName: e.target.value});
  };

  onChangeCompanyLogo =(e)=> {
      this.setState({companyLogo: e.target.value});
      console.log("change"+this.state.speakerName);
  };

  onChangeEmailId =(e) => {
      this.setState({emailId: e.target.value});
  };

  onChangeContact =(e) => {
      this.setState({contact: e.target.value});
  };

  onChangeDescription =(e) => {
      this.setState({description: e.target.value});
  };

  onChangeWebSiteUrl =(e) => {
      this.setState({websiteUrl: e.target.value});
  };


  Delete = (id) => {
      console.log("delete" + id);
      this.state.items.splice(id,1);
      this.setState({items:this.state.items});
      console.log(this.state.items);
  };



  handleValidate13= () =>{
  var x13= document.getElementById("sponsorName").value;
  const num =/[0-9]+/g;
  const spcl =/[^a-zA-Z0\\s]/;
  if(x13=="" || num.test(x13) || spcl.test(x13))
  {
    document.getElementById("sponsorName").style.borderColor="red";
  }
  else{
    document.getElementById("sponsorName").style.borderColor="green";
    return 1;
  }
};

handleValidate14= () =>{
  var x14= document.getElementById("sponsorEmail").value;
  const email = /^[a-z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*)?@[a-z][a-zA-Z-0-9]*\.[a-z]+(\.[a-z]+)?$/;
  if(x14=="" || !email.test(x14))
  {
    document.getElementById("sponsorEmail").style.borderColor="red";
  }
  else{
    document.getElementById("sponsorEmail").style.borderColor="green";
    return 1;
  }
};

handleValidate15= () =>{
  var x15= document.getElementById("sponsorNumber").value;
  const num =/[0-9]+/g;
  if(x15=="" || !num.test(x15) || x15.length<3)
  {
    document.getElementById("sponsorNumber").style.borderColor="red";
  }
  else{
    document.getElementById("sponsorNumber").style.borderColor="green";
    return 1;
  }
};

handleValidate16= () =>{
  var x16= document.getElementById("sponsorDescription").value;
  if(x16==""|| x16.length>150)
  {
    document.getElementById("sponsorDescription").style.borderColor="red";
  }
  else{
    document.getElementById("sponsorDescription").style.borderColor="green";
    return 1;
  }
};

handleValidate= () => {
   if(this.handleValidate13()==1 && this.handleValidate14()==1 && this.handleValidate15()==1 && this.handleValidate16()==1)
   {
     this.setState({check:false});
   }
   else {
     this.setState({check:true});
   }
};

  handleSeventhClick = () => {
    let x ={
    SponsorName: this.state.sponsorName,
    EmailId: this.state.emailId,
    ContactNumber: this.state.contact,
    Website: this.state.websiteUrl,
    Description: this.state.description
   };
  console.log(x);
   $.ajax({
     url:'/sponsorform',
     type:'get',
     dataType:'json',
     data: x,
     success:function(data)
     {
       console.log('data');
       console.log(data);
     }.bind(this)
   });
  };

  render() {
    return (
       <div>
       <div className='col-xs-12'>

       <SponsorList items={this.state.items}
       itemDelete={this.Delete} />

       <Paper style={styles.paper} onTouchTap={this.handleValidate}>
       <Form horizontal style={{fontSize:'12px'}}>
       <FormGroup bsSize='small' style={styles.FormGroup}>
         <Col componentClass={ControlLabel} xs={4}>
           Sponsors Name
         </Col>
         <Col xs={8}>
          <FormControl type="text" id="sponsorName" onBlur={this.handleValidate13} onChange= {this.onChangeSponsorName} placeholder="Only Alphabets" value={this.state.sponsorName} />
         </Col>
       </FormGroup>
       <FormGroup bsSize='small' style={styles.FormGroup}>
         <Col componentClass={ControlLabel} xs={4}>
           Company Logo
         </Col>
         <Col xs={5}>
         <Dropzone ref={(node) => { dropzoneRef = node; }} onDrop={(accepted, rejected) => { this.setState({accepted}) }} style={{width:'100px',height:'30px',border:'1px solid',borderRadius:'2px',borderColor:'#BDC3C7',background:'#ffffff'}}>
             <p>{this.state.accepted.length}files selected</p>
         </Dropzone>
         </Col>
         <Col xs={3}>
         <Button bsSize='small' style={styles.button1} onClick={() => { dropzoneRef.open() }}>Browse</Button>
         </Col>
       </FormGroup>
       <FormGroup bsSize='small'style={styles.FormGroup}>
         <Col componentClass={ControlLabel} xs={4}>
          Email ID
         </Col>
         <Col xs={8}>
          <FormControl type="email" id="sponsorEmail" onBlur={this.handleValidate14} onChange= {this.onChangeEmailId} placeholder="e.g abcdef@xyz.com" value={this.state.emailId} />
         </Col>
       </FormGroup>
       <FormGroup bsSize='small'style={styles.FormGroup}>
         <Col componentClass={ControlLabel} xs={4}>
           Contact Number
         </Col>
         <Col xs={8}>
          <FormControl type="number" id="sponsorNumber" onBlur={this.handleValidate15} onChange= {this.onChangeContact} placeholder="Only Numbers" value= {this.state.contact} />
         </Col>
       </FormGroup>
       <FormGroup bsSize='small'style={styles.FormGroup}>
         <Col componentClass={ControlLabel} xs={4}>
           Description
         </Col>
         <Col xs={8}>
        <FormControl type="text" id="sponsorDescription" onBlur={this.handleValidate16} onChange= {this.onChangeDescription} placeholder="Not More Than 150 Words" value = {this.state.description} />
         </Col>
       </FormGroup>
       <FormGroup bsSize='small'style={styles.FormGroup}>
         <Col componentClass={ControlLabel} xs={4}>
       Website URL
         </Col>
         <Col xs={8}>
          <FormControl type="URL" id="websiteUrl" onChange= {this.onChangeWebSiteUrl} value= {this.state.websiteUrl} />
         </Col>
       </FormGroup>
       </Form>
       </Paper>
       <Button bsSize='small' disabled={this.state.check} style={styles.button1} onClick={this.handleClick} onTouchTap={this.handleSeventhClick}>Save and Next</Button>
       <Button bsSize='small' style={styles.addbutton} onClick={this.handleSubmit} onTouchTap={this.handleSeventhClick}>Add More</Button>
      </div>
    </div>

    );
  }
}

import React from 'react';
import ReactDOM from 'react-dom';
import {Collapse} from 'react-collapse';
import DateTimeField from 'react-bootstrap-datetimepicker';
import DatePicker from 'react-bootstrap-date-picker';
import TimePicker from 'react-bootstrap-time-picker';
import Paper from 'material-ui/Paper';
import backbutton from '../images/back-button.png';
import {Button} from 'react-bootstrap';
import { Form,FormGroup,FormControl,Col,ControlLabel } from 'react-bootstrap';
import RaisedButton from 'material-ui/RaisedButton';
import NavigationClose from 'material-ui/svg-icons/navigation/close';
import Dropzone from 'react-dropzone';
let dropzoneRef;

const styles = {
  paper:{
    background:'#E0E0E0',
    height: '100%',
    width: '100%',
    border:'1px solid',
    marginTop:'11px',
    marginBottom:'11px',
    borderRadius: '13px',
    borderColor:'#BDC3C7',
  },
  heading:{
    marginLeft: '25px',
  },

  headline: {
    fontSize: 24,
    paddingTop: 16,
    marginBottom: 12,
    fontWeight: 400,
  },
  FormGroup:{
   margin: '0px',
   marginTop: '10px',
   marginBottom: '10px'
  },
  button1:{
    background: '#FFD93A ',
    float:'right'
  },
  addbutton:{
    marginRight:'10px',
    float:'right'
  },
};



export class AgendaRow extends React.Component{

  constructor(props) {
    super(props);

    this.state = {
      currentValue:'',
      value1:'',
      open: true,
      accepted: [],
      items: [],
      agendaName: '',
      date: '',
      venue: '',
      description: '',
      id : 0,
      format: "DD/MM/YYYY HH:mm",
      dateformat: "DD/MM/YYYY",
      timeformat: "HH:mm",
      dateTime:"22/08/2017 12:00",
      dateTime1:"22/09/2017 12:00",
      inputFormat: "DD/MM/YYYY HH:mm",
      date: '22/08/2017',
      time1: '00:00',
      time2: '00:00',
    };
  }

  collapse = (e) => {
    this.setState({open:!this.state.open});
  };


    handleDelete = () => {
        console.log("handler")
        this.props.itemDelete(this.props.id);
    };

    render() {
      const {format, mode, inputFormat, dateformat, timeformat,dateTime,dateTime1,date,time1,time2,agendavalue} = this.state;

       return (
        <li key={this.props.id}>

          <div>

          <Paper style={styles.paper} id="agenda" onTouchTap= {this.collapse}>
          <Form horizontal style={{fontSize:'12px'}}>
          <FormGroup controlId="formHorizontalEmail" bsSize='small' style={styles.FormGroup}>
          <Col componentClass={ControlLabel} xs={4}>
          Agenda Name
          </Col>
          <Col xs={8}>
          <FormControl type="text" onChange={this.onChangeAgendaName} value={this.props.item.agendaName} />
          </Col>
          </FormGroup>
          <Collapse isOpened={this.state.open}>
          <FormGroup controlId="formHorizontalEmail" bsSize='small' style={styles.FormGroup}>
          <Col componentClass={ControlLabel} xs={4}>
          Date
          </Col>
          <Col xs={8}>
          <DateTimeField mode="date" inputFormat={dateformat} onChange={this.onChangeDate} value={this.state.date} format={dateformat} dateTime={date}
           defaultText="Select a Date"/>
          </Col>
          </FormGroup>
          <FormGroup controlId="formHorizontalEmail" bsSize='small'style={styles.FormGroup}>
          <Col componentClass={ControlLabel} xs={4}>
          Start Time
          </Col>
          <Col xs={8}>
          <DateTimeField mode="time" inputFormat={timeformat} format={timeformat} dateTime={time1} onChange={this.onChangeTimeChange1} value={this.state.time1}/>
          </Col>
          </FormGroup>
          <FormGroup controlId="formHorizontalEmail" bsSize='small'style={styles.FormGroup}>
          <Col componentClass={ControlLabel} xs={4}>
          End Time
          </Col>
          <Col xs={8}>
          <DateTimeField mode="time"
          inputFormat={timeformat} onChange={this.onChangeTimeChange2} value={this.state.time2} format={timeformat} dateTime={time2} defaultValue={this.props.EndTime}/>
          </Col>
          </FormGroup>
          <FormGroup controlId="formHorizontalEmail" bsSize='small'style={styles.FormGroup}>
          <Col componentClass={ControlLabel} xs={4}>
          Venue
          </Col>
          <Col xs={8}>
          <FormControl type="text" onChange={this.onChangeVenue} value= {this.props.item.venue}  />
          </Col>
          </FormGroup>
          <FormGroup controlId="formHorizontalEmail" bsSize='small'style={styles.FormGroup}>
          <Col componentClass={ControlLabel} xs={4}>
          Description
          </Col>
          <Col xs={8}>
          <FormControl type="text" onChange={this.onChangeDescription} value={this.props.item.description}/>
          </Col>
          </FormGroup>
          </Collapse>
          </Form>
          </Paper>

          <NavigationClose style={{marginLeft:'30px'}}
          onTouchTap={this.handleDelete}/>
          </div>
        </li>
    );
    }
}

export class SpeakerRow extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      open: true,
      accepted: [],
      agendaName: '',
      speakerName: '',
      image:'',
      speakerEmailId: '',
      speakerDesignation: '',
      items: [],
      id : 0
      };
  }


    collapse = (e) => {
      this.setState({open:!this.state.open});
    };


      handleDelete = () => {
          console.log("handler")
          this.props.itemDelete(this.props.id);
      };

      handleValidate8= () =>{
        var x8= document.getElementById("emailId").value;
        const email = /^[a-z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*)?@[a-z][a-zA-Z-0-9]*\.[a-z]+(\.[a-z]+)?$/;
        if(x8=="" || !email.test(x8))
        {
          document.getElementById("emailId").style.borderColor="red";
        }
        else{
          document.getElementById("emailId").style.borderColor="green";
        }
      };

      handleValidate9= () =>{
        var x9= document.getElementById("designation").value;
        const num =/[0-9]+/g;
        const spcl =/[^a-zA-Z0\\s]/;
        if(num.test(x9) || spcl.test(x9) || x9.length>20)
        {
          document.getElementById("designation").style.borderColor="red";
        }
        else{
          document.getElementById("designation").style.borderColor="green";
        }
      };

      handleSpeakerNameValidation= () =>{
        var x19= document.getElementById("name").value;
        const num =/[0-9]+/g;
        const spcl =/[^a-zA-Z0\\s]/;
        if(x19=="" || num.test(x19) || spcl.test(x19))
        {
          document.getElementById("name").style.borderColor="red";
        }
        else{
          document.getElementById("name").style.borderColor="green";
        }
      };



render() {
     const {dateTime, inputFormat, inputFormat1, inputFormat2} = this.state;
  return (

  <li key={this.props.id}>
    <div>
      <Paper style={styles.paper} id= "speaker" onTouchTap= {this.collapse}>
        <Form horizontal style={{fontSize:'12px'}}>
        <FormGroup bsSize='small' style={styles.FormGroup}>
        <Col componentClass={ControlLabel} xs={4}>
          Agenda Name
        </Col>
        <Col xs={8}>
        <select style={{width:'100%'}} id='agendaName1' onChange={this.onChangeAgendaName} floatLabelText={this.props.item.agendaName} value={this.props.item.agendaName} >
        <option>Select Agenda</option>
        </select>
        </Col>
        </FormGroup>
        <FormGroup bsSize='small'style={styles.FormGroup}>
          <Col componentClass={ControlLabel} xs={4}>
           Speaker Name
          </Col>
          <Col xs={8}>
            <FormControl type="text" id="name" onBlur={this.handleSpeakerNameValidation} onChange={this.onChangeSpeakerName} placeholder="Only Alphabets" value={this.props.item.speakerName}/>
          </Col>
        </FormGroup>
        <FormGroup bsSize='small'style={styles.FormGroup}>
        <Col componentClass={ControlLabel} xs={4}>
        Image
        </Col>
        <Col xs={5}>
        <Dropzone ref={(node) => { dropzoneRef = node; }} onDrop={(accepted, rejected) => { this.setState({accepted}) }} style={{width:'100px',height:'30px',border:'1px solid',borderRadius:'2px',borderColor:'#BDC3C7',background:'#ffffff'}}>
            <p>{this.state.accepted.length}files selected</p>
        </Dropzone>
        </Col>
        <Col xs={3}>
        <Button bsSize='small' style={styles.button1} onClick={() => { dropzoneRef.open() }}>Browse</Button>
        </Col>
        </FormGroup>
        <FormGroup bsSize='small'style={styles.FormGroup}>
          <Col componentClass={ControlLabel} xs={4}>
           Speaker Email ID
          </Col>
          <Col xs={8}>
          <FormControl type="email" id="emailId" onBlur={this.handleValidate8} onChange={this.onChangeEmailId} placeholder="e.g abcdef@xyz.com" value={this.props.item.speakerEmailId}/>
          </Col>
        </FormGroup>
        <FormGroup bsSize='small'style={styles.FormGroup}>
          <Col componentClass={ControlLabel} xs={4}>
           Designation
          </Col>
          <Col xs={8}>
          <FormControl type="text" id="designation" onBlur={this.handleValidate9} onChange={this.onChangeDesignation} value={this.props.item.speakerDesignation}/>
          </Col>
        </FormGroup>
        </Form>
     </Paper>
    </div>
    <NavigationClose style={{marginLeft:'30px'}}
    onTouchTap={this.handleDelete}/>
  </li>
  );
}
}

export class ContactPersonRow extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      agendaName: [],
      personName: '',
      emailId: '',
      contact: '',
      open: true,
 };
  };

  collapse = (e) => {
    this.setState({open:!this.state.open});
  };


  handleDelete = () => {
    console.log("handler")
    this.props.itemDelete(this.props.id);
  };

  handleValidate10= () =>{
    var x10= document.getElementById("personName").value;
    const num =/[0-9]+/g;
    const spcl =/[^a-zA-Z0\\s]/;
    if(x10=="" || num.test(x10) || spcl.test(x10))
    {
      document.getElementById("personName").style.borderColor="red";
    }
    else{
      document.getElementById("personName").style.borderColor="green";
    }
  };

  handleValidate11= () =>{
    var x11= document.getElementById("personEmail").value;
    const email = /^[a-z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*)?@[a-z][a-zA-Z-0-9]*\.[a-z]+(\.[a-z]+)?$/;
    if(x11=="" || !email.test(x11))
    {
      document.getElementById("personEmail").style.borderColor="red";
    }
    else{
      document.getElementById("personEmail").style.borderColor="green";
    }
  };

  handleValidate12= () =>{
    var x12= document.getElementById("phone").value;
    const num =/[0-9]+/g;
    if(x12=="" || num.test(x12))
    {
      document.getElementById("phone").style.borderColor="red";
    }
    else{
      document.getElementById("phone").style.borderColor="green";
    }
  };

  render() {
    return (
      <li key={this.props.id}>
        <div>
          <Paper style={styles.paper} id= "contactPerson" onTouchTap= {this.collapse}>
             <Form horizontal style={{fontSize:'12px'}}>
               <FormGroup bsSize='small' style={styles.FormGroup}>
                 <Col componentClass={ControlLabel} xs={4}>
                   Person Name
                 </Col>
                 <Col xs={8}>
                 <FormControl type="text" id="personName" onBlur={this.handleValidate10} placeholder="Only Alphabets" value={this.props.item.personName}/>
                 </Col>
               </FormGroup>
               <FormGroup bsSize='small' style={styles.FormGroup}>
                 <Col componentClass={ControlLabel} xs={4}>
                   Email ID
                 </Col>
                 <Col xs={8}>
                 <FormControl type="email" id="personEmail" onBlur={this.handleValidate11} placeholder="e.g. abcdef@xyz.com" value={this.props.item.emailId}/>
                 </Col>
               </FormGroup>
               <FormGroup bsSize='small'style={styles.FormGroup}>
                 <Col componentClass={ControlLabel} xs={4}>
                Contact
                 </Col>
                 <Col xs={8}>
                  <FormControl type="number" id="phone" onBlur={this.handleValidate12} placeholder="Only Numbers" value={this.props.item.contact}/>
                 </Col>
               </FormGroup>
            </Form>
          </Paper>
        </div>
      <NavigationClose style={{marginLeft:'30px'}}
      onTouchTap={this.handleDelete}/>
      </li>
    );
  }
}


export class SponsorRow extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      open: true,
      accepted: [],
      agendaName: [],
      items : [],
      sponsorName: '',
      companyLogo: '',
      emailId: '',
      contact: '',
      description: '',
      websiteUrl: '',
      id : 0
     };
  }

  collapse = (e) => {
    this.setState({open:!this.state.open});
  };


  handleDelete = () => {
    console.log("handler")
    this.props.itemDelete(this.props.id);
  };


  handleValidate13= () =>{
    var x13= document.getElementById("sponsorName").value;
    const num =/[0-9]+/g;
    const spcl =/[^a-zA-Z0\\s]/;
    if(x13=="" || num.test(x13) || spcl.test(x13))
    {
      document.getElementById("sponsorName").style.borderColor="red";
    }
    else{
      document.getElementById("sponsorName").style.borderColor="green";
    }
  };

  handleValidate14= () =>{
    var x14= document.getElementById("sponsorEmail").value;
    const email = /^[a-z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*)?@[a-z][a-zA-Z-0-9]*\.[a-z]+(\.[a-z]+)?$/;
    if(x14=="" || !email.test(x14))
    {
      document.getElementById("sponsorEmail").style.borderColor="red";
    }
    else{
      document.getElementById("sponsorEmail").style.borderColor="green";
    }
  };

  handleValidate15= () =>{
    var x15= document.getElementById("sponsorNumber").value;
    const num =/[0-9]+/g;
    if(x15=="" || num.test(x15))
    {
      document.getElementById("sponsorNumber").style.borderColor="red";
    }
    else{
      document.getElementById("sponsorNumber").style.borderColor="green";
    }
  };

  handleValidate16= () =>{
    var x16= document.getElementById("sponsorDescription").value;
    if(x16.length>150)
    {
      document.getElementById("sponsorDescription").style.borderColor="red";
    }
    else{
      document.getElementById("sponsorDescription").style.borderColor="green";
    }
  };

  render() {
    return (
      <li key= {this.props.id}>
       <div>
       <Paper style={styles.paper} onTouchTap= {this.collapse}>
       <Form horizontal style={{fontSize:'12px'}}>
       <FormGroup bsSize='small' style={styles.FormGroup}>
         <Col componentClass={ControlLabel} xs={4}>
           Sponsors Name
         </Col>
         <Col xs={8}>
          <FormControl type="text" id="sponsorName" onBlur={this.handleValidate13} onChange= {this.onChangeSponsorName} placeholder="Only Alphabets" value={this.props.item.sponsorName} />
         </Col>
       </FormGroup>
       <FormGroup bsSize='small' style={styles.FormGroup}>
         <Col componentClass={ControlLabel} xs={4}>
           Company Logo
         </Col>
         <Col xs={5}>
         <Dropzone ref={(node) => { dropzoneRef = node; }} onDrop={(accepted, rejected) => { this.setState({accepted}) }} style={{width:'100px',height:'30px',border:'1px solid',borderRadius:'2px',borderColor:'#BDC3C7',background:'#ffffff'}}>
             <p>{this.state.accepted.length}files selected</p>
         </Dropzone>
         </Col>
         <Col xs={3}>
         <Button bsSize='small' style={styles.button1} onClick={() => { dropzoneRef.open() }}>Browse</Button>
         </Col>
       </FormGroup>
       <FormGroup bsSize='small'style={styles.FormGroup}>
         <Col componentClass={ControlLabel} xs={4}>
          Email ID
         </Col>
         <Col xs={8}>
          <FormControl type="email" id="sponsorEmail" onBlur={this.handleValidate14} onChange= {this.onChangeEmailId} placeholder="e.g abcdef@xyz.com" value={this.props.item.emailId} />
         </Col>
       </FormGroup>
       <FormGroup bsSize='small'style={styles.FormGroup}>
         <Col componentClass={ControlLabel} xs={4}>
           Contact Number
         </Col>
         <Col xs={8}>
          <FormControl type="number" id="sponsorNumber" onBlur={this.handleValidate15} onChange= {this.onChangeContact} placeholder="Only Numbers" value= {this.props.item.contact} />
         </Col>
       </FormGroup>
       <FormGroup bsSize='small'style={styles.FormGroup}>
         <Col componentClass={ControlLabel} xs={4}>
           Description
         </Col>
         <Col xs={8}>
        <FormControl type="text" id="sponsorDescription" onBlur={this.handleValidate16} onChange= {this.onChangeDescription}  placeholder="Not More Than 150 Words" value = {this.props.item.description} />
         </Col>
       </FormGroup>
       <FormGroup bsSize='small'style={styles.FormGroup}>
         <Col componentClass={ControlLabel} xs={4}>
       Website URL
         </Col>
         <Col xs={8}>
          <FormControl type="URL" id="websiteUrl" onChange= {this.onChangeWebSiteUrl} value= {this.props.item.websiteUrl} />
         </Col>
       </FormGroup>
       </Form>
       </Paper>
    </div>
    <NavigationClose style={{marginLeft:'30px'}}
    onTouchTap={this.handleDelete}/>
    </li>

    );
  }
}


export class InviteeRow extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      open: true,
      agendaName: [],
      agendavalue: [],
      invitee: '',
      items: [],
      id:0,
     };
  }

  collapse = (e) => {
    this.setState({open:!this.state.open});
  };


  handleDelete = () => {
    console.log("handler")
    this.props.itemDelete(this.props.id);
  };

  handleValidate17= () =>{
    var x17= document.getElementById("invitees").value;
    const num =/[0-9]+/g;
    if(x17=="" || num.test(x17))
    {
      document.getElementById("invitees").style.borderColor="red";
    }
    else{
      document.getElementById("invitees").style.borderColor="green";
    }
  };

  handleValidate18= () =>{
    var x18= document.getElementById("inviteeName").value;
    const num =/[0-9]+/g;
    const spcl =/[^a-zA-Z0\\s]/;
    if(x18=="" || num.test(x18) || spcl.test(x18))
    {
      document.getElementById("inviteeName").style.borderColor="red";
    }
    else{
      document.getElementById("inviteeName").style.borderColor="green";
    }
  };

  render() {
    return (
      <li key={this.props.id}>
       <div>
       {this.props.item.invitee}
    </div>
    <NavigationClose style={{marginLeft:'30px'}}
    onTouchTap={this.handleDelete}/>
    </li>
    );
  }
}

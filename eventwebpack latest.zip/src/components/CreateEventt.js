import React from 'react';
import {Link} from 'react-router-dom';
import DateTimeField from 'react-bootstrap-datetimepicker';
import TimezonePicker from 'react-bootstrap-timezone-picker';
import 'react-bootstrap-timezone-picker/dist/react-bootstrap-timezone-picker.min.css';
import {Tabs, Tab} from 'material-ui/Tabs';
import Paper from 'material-ui/Paper';
import backbutton from '../images/back-button.png';
import {Button} from 'react-bootstrap';
import SwipeableViews from 'react-swipeable-views';
import { Form,FormGroup,FormControl,Col,ControlLabel } from 'react-bootstrap';
import RaisedButton from 'material-ui/RaisedButton';
import {RadioButton, RadioButtonGroup} from 'material-ui/RadioButton';
import $ from 'jquery';
import CreateEvent1 from './CreateEvent1.js';
import CreateEvent2 from './CreateEvent2.js';
import CreateEvent3 from './CreateEvent3.js';
import CreateEvent4 from './CreateEvent4.js';
import CreateEvent5 from './CreateEvent5.js';
import CreateEvent6 from './CreateEvent6.js';
import CreateEvent7 from './CreateEvent7.js';
import CreateEvent8 from './CreateEvent8.js';

const styles = {
  paper:{
    background:'#E0E0E0',
    height: '100%',
    width: '100%',
    border:'1px solid',
    marginTop:'11px',
    marginBottom:'11px',
    borderRadius: '13px',
    borderColor:'#BDC3C7',
  },
  heading:{
    marginLeft: '25px',
  },
  headline: {
    fontSize: 24,
    paddingTop: 16,
    marginBottom: 12,
    fontWeight: 400,
  },
  slide: {
    padding: 20,
  },
  FormGroup:{
   margin: '0px',
   marginTop: '10px',
   marginBottom: '10px'
  },
  button1:{
    background: '#FFD93A ',
    float:'right'
  },
  addbutton:{
    marginRight:'10px',
    float:'right'
  },
  uploadbutton:{
    marginRight:'10px',
    float:'right'
  },
  radioButton: {
    marginBottom: '16px',
  },
};

export default class CreateEventt extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      slideIndex: 0,
      value:'',
      currentValue:'',
      format: "DD/MM/YY HH:mm",
      dateformat: "DD/MM/YY",
      timeformat: "HH:mm",
      inputFormat: "DD/MM/YYYY HH:mm",
      dateTime:"22/08/17 12:00",
      dateTime1:"22/08/17 12:00",
      date: '22/08/17',
      startTime: '00:00',
      endTime: '00:00',
      agendaName: [],
      agendavalue: [],
      agendaList:[]
      };
  }

  handleChange = (value) => {
    this.setState({
      slideIndex: value,
    });
    if(this.state.slideIndex==1)
  {

      console.log('componentDidMount');
      $.ajax({
        url:'/agendaname',
        type:'GET',
        dataType:'json',
        success:function(data)
        {
          console.log('data from server to createeventpage');
          console.log(data);
         this.setState({agendaList:data.DbData});
          //  data.DbData.forEach((data,i)=>{
          //     this.state.itemNumber.push(<MenuItem value={data.AgendaName} key={i} primaryText={data.AgendaName} />);
          // });

       }.bind(this)
        });

  }
  };

  handleChange0 = (newValue) => this.setState({ currentValue: newValue });

  handleStartDateTime = (newDate) => this.setState({ dateTime: newDate });

  handleEndDateTime = (newDate1) => this.setState({ dateTime1: newDate1 });

  handleAgendaDate = (date1) => this.setState({date: date1});
  handleAgendaTime = (startTime) => this.setState({startTime: startTime});
  handleAgendaTime2 = (endTime) => this.setState({endTime: endTime});

  handleClick = () => {
    const {slideIndex} = this.state;
    if(slideIndex<7){
    this.setState({
      slideIndex: slideIndex+1,
    });
  };
  };

  render() {
       const {format, mode, inputFormat, dateformat, timeformat,dateTime,dateTime1,date,startTime,endTime,agendavalue} = this.state;
    return (
      <div className='col-xs-12 section'>
      <div className='row'>
      <div className='col-xs-2'>
      <Link to='/demoevent'>
      <p><img src={backbutton} style={{width:'70%',marginTop:"5px"}}/></p>
      </Link>
      </div>
      <div className='col-xs-8'>
      <center><h4><b>Create Event</b></h4></center>
      </div>
      </div>
      <div>
        <Tabs
          onChange={this.handleChange}
          value={this.state.slideIndex}
          inkBarStyle={{background: '#000000 '}}
          tabItemContainerStyle={{background:'#FFD93A'}}
        >
          <Tab label="1" value={0}  style={{color: '#000000'}}/>
          <Tab label="2" value={1}  style={{color: '#000000'}}/>
          <Tab label="3" value={2}  style={{color: '#000000'}}/>
          <Tab label="4" value={3}  style={{color: '#000000'}}/>
          <Tab label="5" value={4}  style={{color: '#000000'}}/>
          <Tab label="6" value={5}  style={{color: '#000000'}}/>
          <Tab label="7" value={6}  style={{color: '#000000'}}/>
          <Tab label="8" value={7}  style={{color: '#000000'}}/>
        </Tabs>
        <SwipeableViews
          index={this.state.slideIndex}
          onChangeIndex={this.handleChange}
        >

       <div className='col-xs-12'>
       <h4><b> Add Event</b> </h4>
       <CreateEvent1 />
       </div>

       <div className='col-xs-12'>
       <h4><b> Add Agenda</b> </h4>
       <CreateEvent2 />
       </div>

       <div className='col-xs-12'>
       <h4><b> Add Speaker</b> </h4>
       <CreateEvent3 agendaList={this.state.agendaList}/>
       </div>

       <div className='col-xs-12'>
       <h4><b> Add Contact Person</b> </h4>
       <CreateEvent4 />
       </div>

       <div className='col-xs-12'>
       <h4><b>Add Documents & Notifications</b></h4>
       <CreateEvent5 />
       </div>

      <div className='col-xs-12'>
      <h4><b>Add Add Images</b></h4>
      <CreateEvent6 />
      </div>

      <div className='col-xs-12'>
      <h4><b>Add Sponsors</b></h4>
      <CreateEvent7 />
      </div>

      <div className='col-xs-12'>
      <h4><b>Send Invites</b></h4>
      <CreateEvent8 />
      </div>

      </SwipeableViews>
      </div>
      </div>
    );
  }
}

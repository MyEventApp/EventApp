import React, { Component} from 'react';
import { Button } from 'react-bootstrap';
import {Link} from 'react-router-dom';
import Paper from 'material-ui/Paper';
import Dashboard from './Dashboard';
import PastEvent from './PastEvent';
import Filter from '../images/Filter.png';
import Search from '../images/search.png';
import '../css/style.css';

const styles = {
 button:{
   background: '#FFD93A ',
 }
};

class LandingPage extends Component  {

 constructor(){
   super();
   this.state={events: true,event1: false};
 };

 handleChange = () => {
 document.getElementById("button1").style.backgroundColor="#FFD93A ";
 document.getElementById("button2").style.backgroundColor="#E0E0E0 ";
 this.setState({event1: false});
 this.setState({events: true});
};

 handleChange1 = () => {
 document.getElementById("button1").style.backgroundColor="#E0E0E0 ";
 document.getElementById("button2").style.backgroundColor="#FFD93A ";
 this.setState({events: false});
 this.setState({event1: true});
};

handleSearch = () => {
 document.getElementById("txtBox").style.visibility= "visible";
 document.getElementById("txtBox").style.display = 'block';
};

handleText = () => {
document.getElementById("txtBox").style.display = 'block';
document.getElementById("txtBox").style.visibility= "visible";
};

render(){
    var projectData = this.props.eventData.map(function(data) {
       return (
         <div key={data.EventId}>
         <Dashboard
         EventName={data.EventName} StartDate={data.StartDate} EndDate={data.EndDate} Location={data.Location} EventId={data.EventId}
         />
          </div> );
     }.bind(this));

return(
 <div className='col-xs-12 section'>
 <div className='row'>
   <div className='col-xs-6'>

    <Button block active  id= "button1" value="Upcoming" bsSize='small' style={styles.button} onClick={this.handleChange}>Upcoming Events</Button>

   </div>
   <div className='col-xs-6'>
   <Button block active id= "button2" value="PastEvent" bsSize='small' onClick={this.handleChange1}>Past Events</Button>
   </div>

 </div>
 <div className='row'>

   <img src={Filter} style={{height:'10%',width:'10%',marginLeft:'87%',marginTop:'10px'}} />
 </div>
 <div className='row'>

 {this.state.events ? projectData : <PastEvent/> || this.state.event1 ? <PastEvent/> : projectData}

 </div>
 </div>
);
}
}

export default LandingPage;

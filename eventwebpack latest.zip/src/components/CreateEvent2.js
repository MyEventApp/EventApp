import React from 'react';
import ReactDOM from 'react-dom';
import {Collapse} from 'react-collapse';
import DateTimeField from 'react-bootstrap-datetimepicker';
import DatePicker from 'react-bootstrap-date-picker';
import TimePicker from 'react-bootstrap-time-picker';
import Paper from 'material-ui/Paper';
import backbutton from '../images/back-button.png';
import {Button} from 'react-bootstrap';
import { Form,FormGroup,FormControl,Col,ControlLabel } from 'react-bootstrap';
import RaisedButton from 'material-ui/RaisedButton';
import {AgendaList} from './List.js';
import $ from 'jquery';

const styles = {
  paper:{
    background:'#E0E0E0',
    height: '100%',
    width: '100%',
    border:'1px solid',
    marginTop:'11px',
    marginBottom:'11px',
    borderRadius: '13px',
    borderColor:'#BDC3C7',
  },
  heading:{
    marginLeft: '25px',
  },

  headline: {
    fontSize: 24,
    paddingTop: 16,
    marginBottom: 12,
    fontWeight: 400,
  },
  FormGroup:{
   margin: '0px',
   marginTop: '10px',
   marginBottom: '10px'
  },
  button1:{
    background: '#FFD93A ',
    float:'right'
  },
  addbutton:{
    marginRight:'10px',
    float:'right'
  },
};

var addmore={};

export default class CreateEvent2 extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      slideIndex:0,
      open: true,
      accepted: [],
      items: [],
      agendaName: '',
      venue: '',
      description: '',
      id : 0,
      agendaName: [],
      agendavalue: [],
      check:true,
      format: "DD/MM/YYYY HH:mm",
      dateformat: "DD/MM/YYYY",
      timeformat: "HH:mm",
      dateTime:"22/08/2017 12:00",
      dateTime1:"22/09/2017 12:00",
      inputFormat: "DD/MM/YYYY HH:mm",
      date: '22/08/2017',
      time1: '00:00',
      time2: '00:00',
    };
  }

  collapse = (e) => {
    this.setState({open:!this.state.open});
  };

  onDrop(files) {
    this.setState({
      files
    });
  };

  handleClick = () => {
    const {slideIndex} = this.state;
    if(slideIndex<7){
    this.setState({
      slideIndex: slideIndex+1,
    });};
  };

  handleSubmit =(e) => {

    addmore[this.state.agendaName]=this.state.date;
    e.preventDefault();
    console.log("allow");

    this.setState({id:this.state.id+1});
    console.log("state id value is =" + this.state.id);

    var nextItems = this.state.items.concat({agendaName: this.state.agendaName,
                                                date: this.state.date,
                                                time1: this.state.time1,
                                                time2: this.state.time2,
                                                venue: this.state.venue,
                                                description: this.state.description,
                                                id:this.state.id}
                                              );
                                              console.log("nextitems = ");
                                              console.log(nextItems);
      var nextText = '';
      this.setState({items: nextItems, agendaName: nextText, date: nextText, time1: nextText, time2: nextText, venue: nextText, description: nextText});

console.log("all data =" +  this.state.items);
  };

  handleAgendaDate = (date1) => this.setState({date: date1});
  handleAgendaTime = (startTime) => this.setState({startTime: startTime});
  handleAgendaTime2 = (endTime) => this.setState({endTime: endTime});

  onChangeAgendaName =(e) => {
      this.setState({agendaName:document.getElementById("agendaName").value});
  };

  onChangeDate =(date1)=> {
      this.setState({date:date1});
      console.log("change"+this.state.date);
  };

  onChangeTimeChange1 =(startTime) => {
      this.setState({time1: startTime});
      console.log("change"+this.state.time1);

  };

  onChangeTimeChange2 =(endTime) => {
      this.setState({time2:endTime});
      console.log("change"+this.state.time2);

  };

  onChangeVenue =(e) => {
      this.setState({venue: e.target.value});
  };

  onChangeDescription =(e) => {
      this.setState({description: e.target.value});
  };

  Delete = (id) => {
      console.log("delete" + id);
      this.state.items.splice(id,1);
      this.setState({items:this.state.items});
      console.log(this.state.items);
  };

  handleSecondClick = () => {
    let x ={
    AgendaName: document.getElementById('agendaName').value,
    Date: this.state.date,
    StartTime: this.state.time1,
    EndTime: this.state.time2,
    Venue: document.getElementById('venue').value,
    Description: document.getElementById('description').value,
   };
  console.log(x);
   $.ajax({
     url:'/agendaform',
     type:'get',
     dataType:'json',
     data: x,
     success:function(data)
     {
       console.log('data');
       console.log(data);

    // $.ajax({
    //   url:'/agendaname',
    //   type:'GET',
    //   dataType:'json',
    //   success:function(data)
    //   {
    //     console.log('data from server to createeventpage');
    //     this.setState({agendaName:data.DbData});
    //     var obj = this.state.agendaName;
    //     for (var i=0; i<=obj.length; i++){
    //       for(var key in obj[i]){
    //         let a = this.state.agendavalue;
    //         a[i] = obj[i][key];
    //         this.setState({agendavalue: a});
    //       };
    //     };
    //       console.log(this.state.agendavalue);
    //       var optionList = document.getElementById('agendaName1').options;
    //       var options = this.state.agendavalue;
    //       console.log(options);
    //     options.forEach( (option) => optionList.add( new Option(option ) ));
    //
    //     }.bind(this)
    // });

  }.bind(this)
  });
  };

  handleValidate5= () =>{
    var x5= document.getElementById("agendaName").value;
    if(x5=="")
    {
      document.getElementById("agendaName").style.borderColor="red";
    }
    else{
      document.getElementById("agendaName").style.borderColor="green";
      return 1;
    }
  };

  handleValidate6= () =>{
    var x6= document.getElementById("venue").value;
    if(x6=="" || x6.length>20)
    {
      document.getElementById("venue").style.borderColor="red";
    }
    else{
      document.getElementById("venue").style.borderColor="green";
      return 1;
    }
  };

  handleValidate7= () =>{
    var x7= document.getElementById("description").value;
    if(x7==""|| x7.length>150)
    {
      document.getElementById("description").style.borderColor="red";
    }
    else{
      document.getElementById("description").style.borderColor="green";
      return 1;
    }
  };

  handleValidate= () => {
     if(this.handleValidate5()==1 && this.handleValidate6()==1 && this.handleValidate7()==1)
     {
       this.setState({check:false});
     }
     else {
       this.setState({check:true});
     }
  };
  render() {

    const {format, mode, inputFormat, dateformat, timeformat,dateTime,dateTime1,date,time1,time2,agendavalue} = this.state;
    return (
       <div className='col-xs-12'>

       <AgendaList items={this.state.items}
       itemDelete={this.Delete} />

       <Paper style={styles.paper} id="agenda" onTouchTap={this.handleValidate}>
       <Form horizontal style={{fontSize:'12px'}}>
       <FormGroup bsSize='small' style={styles.FormGroup}>
       <Col componentClass={ControlLabel} xs={4}>
       Agenda Name
       </Col>
       <Col xs={8}>
       <FormControl type="text" id="agendaName" onBlur={this.handleValidate5} placeholder="Enter Text Here" onChange={this.onChangeAgendaName} />
       </Col>
       </FormGroup>
       <Collapse isOpened={this.state.open}>
       <FormGroup bsSize='small' style={styles.FormGroup}>
       <Col componentClass={ControlLabel} xs={4}>
       Date
       </Col>
       <Col xs={8}>
       <DateTimeField mode="date" inputFormat={dateformat} onChange={this.onChangeDate} value={this.state.date} format={dateformat} dateTime={date}
        defaultText="Select a Date"/>
       </Col>
       </FormGroup>
       <FormGroup bsSize='small'style={styles.FormGroup}>
       <Col componentClass={ControlLabel} xs={4}>
       Start Time
       </Col>
       <Col xs={8}>
       <DateTimeField mode="time" inputFormat={timeformat} format={timeformat} dateTime={time1} onChange={this.onChangeTimeChange1} value={this.state.time1}/>
       </Col>
       </FormGroup>
       <FormGroup bsSize='small'style={styles.FormGroup}>
       <Col componentClass={ControlLabel} xs={4}>
       End Time
       </Col>
       <Col xs={8}>
       <DateTimeField mode="time"
       inputFormat={timeformat} onChange={this.onChangeTimeChange2} value={this.state.time2} format={timeformat} dateTime={time2} defaultValue={this.props.EndTime}/>
       </Col>
       </FormGroup>
       <FormGroup bsSize='small'style={styles.FormGroup}>
       <Col componentClass={ControlLabel} xs={4}>
       Venue
       </Col>
       <Col xs={8}>
       <FormControl type="text" id="venue"  type="text" onBlur={this.handleValidate6} placeholder="Not More Than 20 Words" onChange={this.onChangeVenue} value={this.state.venue}/>
       </Col>
       </FormGroup>
       <FormGroup bsSize='small'style={styles.FormGroup}>
       <Col componentClass={ControlLabel} xs={4}>
       Description
       </Col>
       <Col xs={8}>
       <FormControl type="text" id="description" onBlur={this.handleValidate7} placeholder="Not more Than 150 Words" onChange={this.onChangeDescription} value={this.state.description}/>
       </Col>
       </FormGroup>
       </Collapse>
       </Form>
       </Paper>
       <Button bsSize='small' disabled={this.state.check} style={styles.button1} onClick={this.handleClick} onTouchTap={this.handleSecondClick}>Save and Next</Button>
       <Button bsSize='small' style={styles.addbutton} onClick={this.handleSubmit} onTouchTap={this.handleSecondClick}>Add More</Button>
       </div>

    );
  }
}

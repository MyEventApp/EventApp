import React, { Component} from 'react';
import {Link} from 'react-router-dom';
import Paper from 'material-ui/Paper';
import { Button } from 'react-bootstrap';
import Avatar from 'material-ui/Avatar';
import Speakerphoto1 from '../images/photo1.png';
import Speakerphoto2 from '../images/download1.jpg';
import backbutton from '../images/back-button.png';
import rightarrow from '../images/RIght-arrow-Icons.png';

const styles={
  paper:{
      background: '#FFD93A',
      borderRadius:"7px",
      height: '100%',
      marginBottom:'11px',
      borderColor:'#BDC3C7',
    },
  };

export class SpeakersList extends Component {
  render() {
    console.log(this.props.speakerList);
    var speakerList = this.props.speakerList.map(function(data) {
    return (
          <Speakers key={data.SpeakerId}
              SpeakerName={data.Name} Designation={data.Designation} Email={data.EmailId} EventId={data.EventId} />
            );
          }.bind(this));
      return(
        <div className='col-xs-12 section'>
        <div className='row'>
        <div className='col-xs-2'>
        <Link to={'/details/'+JSON.parse(sessionStorage.Id)}>
        <p><img src={backbutton} style={{width:'70%',marginTop:"5px"}}/></p>
        </Link>
        </div>
        <div className='col-xs-8'>
        <center><h4><b>Speakers</b></h4></center>
        </div>
        </div>
        {speakerList}
        </div>
      )}
  };

export class Speakers extends Component  {
render() {
return (
  <div>
  <Paper zDepth={1} rounded={true} style={styles.paper}>
  <div className='row'>
  <div className='col-xs-2'>
<Avatar src={Speakerphoto2} style={{marginTop:"6px",marginLeft:"5px"}}/>
</div>
<div className='col-xs-8'>
<p>{this.props.SpeakerName}<br></br>
{this.props.Designation}<br></br>
{this.props.Email}</p>
</div>
<div className='col-xs-2'>
</div>
</div>
</Paper>
</div>
);
}
}

import React, { Component} from 'react';
import {Link} from 'react-router-dom';
import {Card,CardHeader,CardText} from 'material-ui/Card';
import backbutton from '../images/back-button.png';

const styles={
card:{
  padding:'8px',
  border:'1px solid',
  marginTop:'7px',
  borderRadius: '7px',
  borderColor:'#BDC4C7',
  background:'#FFD84A'
}
};

export default class Notifications extends Component {

   render() {
   return (
     <div className='col-xs-12 section'>
     <div className='row'>
     <div className='col-xs-2'>
     <Link to='/home'>
     <p><img src={backbutton} style={{width:'70%',marginTop:"5px"}}/></p>
     </Link>
     </div>
     <div className='col-xs-8'>
     <center><h4><b>Notifications</b></h4></center>
     </div></div>
     <Card style={{borderRadius:'7px'}}>
     <CardHeader title={this.props.notifications.length+" new notifications"} style={styles.card} />
     </Card>
      </div>
   );
}
}

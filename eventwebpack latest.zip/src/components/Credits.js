import React, { Component} from 'react';
import {Link} from 'react-router-dom';
import Paper from 'material-ui/Paper';
import Divider from 'material-ui/Divider';
import backbutton from '../images/back-button.png';

class Credits extends Component  {
render() {
return (
  <div className='col-xs-12 section'>
  <div className='row'>
  <div className='col-xs-2'>
  <Link to='/demoevent'>
  <p><img src={backbutton} style={{width:'70%',marginTop:"5px"}}/></p>
  </Link>
  </div>
  <div className='col-xs-8'>
  <center><h4><b>Credits</b></h4></center>
  </div>
  <div className='col-xs-12'style={{marginBottom:'5px'}}>
  <Paper rounded={true} style={{borderRadius:"7px",background:'#EBE9E9'}}>
  <h5 style={{background:'#FFD93A ', borderRadius:'6px', padding:'6px'}}><strong>Contributors</strong></h5>
  <p style={{marginLeft:"7px"}}>We would like to express our gratitude to everyone who has contributed in developing Wipro EVON.</p>
<div className='row'>
<div className='col-xs-6' style={{marginLeft:"7px"}}>
<p><b>-</b>Robert Racine<br></br>
<b>-</b>Swarup Shastri<br></br>
<b>-</b>Vishal Kumar Roy<br></br>
<b>-</b>Tony Elangbam</p>
</div>
<div className='col-xs-5'>
<p><b>-</b>Damini Verma<br></br>
<b>-</b>Priyanka Thakur<br></br>
<b>-</b>Samridhi Bhalla<br></br>
<b>-</b>Shubham Dangi</p>
</div>
</div>
</Paper>
</div>

<div className='col-xs-12'style={{marginBottom:'10px'}}>
<Paper rounded={true} style={{borderRadius:"7px",background:'#EBE9E9'}}>
<h5 style={{background:'#FFD93A ', borderRadius:'6px', padding:'6px'}}><strong>Open-Source Plugins</strong></h5>
<p style={{marginLeft:"7px"}}>We would like to acknowledge the following Open-Source Plugins used in the Product.</p>
<div className='row'>
<div className='col-xs-8' style={{marginLeft:"7px"}}>
<p><b>-</b>React JS<br></br>
<b>-</b>Material-UI<br></br>
<b>-</b>React-Router<br></br>
<b>-</b>React-Bootstrap<br></br>
<b>-</b>React-TinyMCE Editor</p>
</div>
</div>
</Paper>
</div>
  </div>
  </div>
);
}
}
export default Credits;

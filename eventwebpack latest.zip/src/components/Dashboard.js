  import React, { Component} from 'react';
  import {Link} from 'react-router-dom';
  import {Card, CardMedia, CardText} from 'material-ui/Card';
  import Paper from 'material-ui/Paper';
  import IconButton from 'material-ui/IconButton';
  import img1 from '../images/bg-slide-01.jpg';
  import img2 from '../images/eventt-image2.png';
  import img3 from '../images/eventt-image3.png';
  import img4 from '../images/eventt-image4.png';
  import img5 from '../images/download.jpg';
  import calendar from '../images/calender.png';
  import location from '../images/location.png';
  import '../css/style.css';

  const styles={
    paper:{
        background:'#E0E0E0',
        height: '100%',
        border:'1px solid',
        //marginTop:'11px',
        marginBottom:'11px',
        // borderRadius: '13px',
        borderColor:'#BDC3C7',
    },
    content:{
      marginLeft:'6px',
    },
  };

  class Dashboard extends Component  {
    render() {
  console.log(this.props.EventId);
    return (
    <div className='col-xs-12'>
    <Link to={'/details/'+ this.props.EventId}>
    <Paper zDepth={1} rounded={true} style={styles.paper}>
    <div className='row'>
    <div className='col-xs-8'>
    <p style={styles.content}><strong>{this.props.EventName}</strong></p>
    <p><img src={calendar} style={{width:'12%'}}/>{this.props.StartDate} to {this.props.EndDate}</p>
    <p><img src={location} style={{width:'12%'}}/>{this.props.Location}</p>
    </div>
    <div className='col-xs-4'>
     <img src={img2} alt="image not found" style={{height:'100%',width:'100%', padding:'2px'}}/>
   </div>
   </div>
   </Paper>
   </Link>
   </div>
  );
  }
  }
  export default Dashboard;

import React, { Component} from 'react';
import {Link} from 'react-router-dom';
import {Card, CardMedia, CardText} from 'material-ui/Card';
import Paper from 'material-ui/Paper';
import IconButton from 'material-ui/IconButton';
import img1 from '../images/bg-slide-01.jpg';
import img2 from '../images/eventt-image2.png';
import img3 from '../images/eventt-image1.png';
import img4 from '../images/eventt-image4.png';
import img5 from '../images/download.jpg';
import calendar from '../images/calender.png';
import location from '../images/location.png';
import Dashboard from './Dashboard';
import '../css/style.css';

const styles = {
 paper:{
     background:'#E0E0E0',
     height: '100%',
     border:'1px solid',
     marginTop:'11px',
     marginBottom:'11px',
     // borderRadius: '13px',
     borderColor:'#BDC3C7',
 },
 content:{
   marginLeft:'6px',
 },
};

class DemoEvent extends Component  {
render(){

// var projectData = this.props.eventData.map(function(data) {
//      return (
//        <div key={data.EventId}>
//        <Dashboard
//        EventName={data.EventName} StartDate={data.StartDate} EndDate={data.EndDate} Location={data.Location} EventId={data.EventId}
//        />
//         </div> );
//    }.bind(this));
return(
 <div className='col-xs-12 section'>
<Dashboard/>
 </div>
);
}
}

export default DemoEvent;

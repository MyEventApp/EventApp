import React, { Component} from 'react';
import {Link} from 'react-router-dom';
import Paper from 'material-ui/Paper';
import img1 from '../images/Event-app-new.png';
import img2 from '../images/eventt-image3.png';
import Avatar from 'material-ui/Avatar';
import Divider from 'material-ui/Divider';
import Dialog from 'material-ui/Dialog';
import calendar from '../images/calender.png';
import location from '../images/location.png';
import imgagenda from '../images/Agenda.png';
import imgattendee from '../images/Attendee.png';
import backbutton from '../images/back-button.png';
import imgdiscussion from '../images/Discussion.png';
import imgspeaker from '../images/Profile-2.png';
import imgmyschedule from '../images/My-Schedule.png';
import imgsponsors from '../images/Sponsors.png';
import imggallery from '../images/Gallery.png';
import RaisedButton from 'material-ui/RaisedButton';
import { Button,Form,FormGroup,FormControl,Col,ControlLabel } from 'react-bootstrap';
import ResponseModal from './ResponseModal';
import $ from 'jquery';

const styles = {
  button:{
    background: '#FFD84A',
    marginRight: '5px',
  },
  sendbutton:{
    background: '#FFD84A',
    marginLeft: '5px',
  },
  cm:
   {
     width:'100%',
     height:'120px',
   },
  heading:{
     marginLeft:"25px",
   }
   }

// export class EventData extends Component {
//   render() {
//           console.log(this.props.eventDetails);
//
//           var eventDetails = this.props.eventDetails.map(function(data) {
//                 return (
//                   <EventDetails key={data.EventId}
//                   EventName={data.EventName} StartDate={data.StartDate} EndDate={data.EndDate} StartTime={data.StartTime} EndTime={data.EndTime} Location={data.Location}
//                    EventId={data.EventId}/>);
//               }.bind(this));
//               return(
//                 <div>{eventDetails}</div>
//        );
//      }
// };

export default class EventDetails extends Component  {
  constructor(props) {
    super(props);
    this.state = {open: false};
  };

  handleOpen = () => this.setState({open: true});

  handleClose = () => this.setState({open: false});

  handleResponse= () => {
    var e = document.getElementById("rsvpStatus");
    var f= document.getElementById("food");
    let x ={
      RSVPStatus : e.options[e.selectedIndex].value,
      CostCenter : document.getElementById("costCenter").value,
      FoodPreference : f.options[f.selectedIndex].value,
      TransportDetails : document.getElementById("transport").value,
      EventId: this.props.eventDetails.EventId
    };
  console.log(x);
  $.ajax({
    url:'/rsvpData',
    type:'get',
    dataType:'json',
    data: x,
    success:function(data)
    {
      console.log('data');
      console.log(data);
    }.bind(this)
   });
  }

 render() {
    var eventDetails = this.props.eventDetails;
   const actions = [
     <Button active bsSize='small'onTouchTap={this.handleClose}>Cancel</Button>,
     <Button active bsSize='small' style={styles.sendbutton} onTouchTap={this.handleResponse}>Send</Button>]
 return (
  <div className="col-xs-12 section">
  <div className='row'>
  <div className='col-xs-2'>
  <Link to={'/home/'+ eventDetails.EventId}>
  <p><img src={backbutton} style={{width:'70%',marginTop:"5px"}}/></p>
  </Link>
  </div>
  <div className='col-xs-8'>
  <center><h4><b>{eventDetails.EventName}</b></h4></center>
  </div></div>
  <div>
  <Paper zDepth={2} rounded={true} style={{width:'100%',height:'100%'}}>
    <img src={img1} style={styles.cm}  alt="image not found" />
    <RaisedButton label="RSVP" buttonStyle={{backgroundColor:'#FFD93A',borderRadius:'25px'}} style={{position:'absolute',top:'130px',right:'18px',borderRadius:'25px',height:'20px'}}
    onClick={this.handleOpen}/>
    <Dialog
          modal={true}
          open={this.state.open}
          actions={actions}
          onRequestClose={this.handleClose}
        >
 <ResponseModal/>
        </Dialog>

  </Paper>
</div>
  <Paper rounded={true} style={{marginTop:'5px',background:'#FFD93A '}}>
    <p style={{fontSize:'12px'}}>  <img src={calendar} style={{width:'10%'}}/>{eventDetails.StartDate} - {eventDetails.EndDate}</p>
    <p style={{fontSize:'12px'}}>  <img src={location} style={{width:'10%'}}/>{eventDetails.Location}</p>
  </Paper>

   <Paper rounded={true} style={{background:'#E6E7E8'}}>
    <div className="row" style={{textAlign:'center'}}>
    <div className="col-xs-4" >
    <Link to={'/agendalist/'+ eventDetails.EventId} style={{color:'#000000'}}>
    <img src={imgagenda} style={{width:'45%',marginTop:'3px'}} />
    <p>Agenda</p></Link></div>

    <div className="col-xs-4" >
    <Link to={'/speakers/'+ eventDetails.EventId} style={{color:'#000000'}}>
    <img src={imgspeaker} style={{width:'45%',marginTop:'3px'}} />
    <p>Speakers</p></Link></div>
    <div className="col-xs-4" >
    <Link to='/attendees' style={{color:'#000000'}}>
    <img src={imgattendee} style={{width:'45%',marginTop:'3px'}} />
    <p>Attendees</p></Link></div>
    </div>

    <div className="row" style={{textAlign:'center'}}>
    <div className="col-xs-4" >
    <Link to={'/contact/'+ eventDetails.EventId} style={{color:'#000000'}}>
    <img src={imgdiscussion} style={{width:'45%',marginTop:'3px'}} />
    <p>Contact Us</p></Link></div>
    <div className="col-xs-4" >
    <Link to={'/sponsorlist/'+ eventDetails.EventId} style={{color:'#000000'}}>
    <img src={imgsponsors} style={{width:'45%',marginTop:'3px'}} />
    <p>Sponsors</p></Link></div>
    <div className="col-xs-4" >
    <Link to='/gallery' style={{color:'#000000'}}>
    <img src={imggallery} style={{width:'45%',marginTop:'3px'}} />
    <p>Gallery</p></Link></div>
    </div>
 </Paper>

 <Paper zDepth={2} rounded={true} style={{borderRadius:"7px"}}>
 <h5 style={{background:'#FFD93A ', borderRadius:'6px', padding:'6px'}}><strong>Updates</strong></h5>
 <p style={{paddingLeft: '6px'}}>Arrival of a significant point in time. In project management, an event marks the point in time when a task is completed. See also events.
 </p>
 </Paper>
 </div>
 );
}
}

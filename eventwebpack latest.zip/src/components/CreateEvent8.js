import React from 'react';
import {Link} from 'react-router-dom';
import {Collapse} from 'react-collapse';
import Paper from 'material-ui/Paper';
import backbutton from '../images/back-button.png';
import {Button} from 'react-bootstrap';
import { Form,FormGroup,FormControl,Col,ControlLabel } from 'react-bootstrap';
import {RadioButton, RadioButtonGroup} from 'material-ui/RadioButton';
import {InviteeList} from './List.js';
let dropzoneRef;
import $ from 'jquery';

const styles = {
  paper:{
    background:'#E0E0E0',
    height: '100%',
    width: '100%',
    border:'1px solid',
    marginTop:'11px',
    marginBottom:'11px',
    borderRadius: '13px',
    borderColor:'#BDC3C7',
  },
  heading:{
    marginLeft: '25px',
  },

  headline: {
    fontSize: 24,
    paddingTop: 16,
    marginBottom: 12,
    fontWeight: 400,
  },
  FormGroup:{
   margin: '0px',
   marginTop: '10px',
   marginBottom: '10px'
  },
  button1:{
    background: '#FFD93A ',
    float:'right'
  },
  radioButton: {
    marginBottom: '16px',
  },
};

var addmore = {};

export default class CreateEvent8 extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      slideIndex:0,
      open: true,
      agendaName: [],
      agendavalue: [],
      invitee: '',
      items: [],
      id:0,
      check:true,
      value:''
     };
  }

  onDrop(files) {
    this.setState({
      files
    });
  };

  handleClick = () => {
    const {slideIndex} = this.state;
    if(slideIndex<7){
    this.setState({
      slideIndex: slideIndex+1,
    });};
  };

  handleSubmit =(e) => {

    addmore[this.state.invitee]=this.state.invitee;
    e.preventDefault();
    console.log("allow");

    this.setState({id:this.state.id+1});
    console.log("state id value is =" + this.state.id);

    var nextItems = this.state.items.concat({invitee: this.state.invitee,
                                                id:this.state.id}
                                              );
                                              console.log("nextitems = "+ nextItems.invitee);
      var nextText = '';
      this.setState({items: nextItems, invitee: nextText, no: nextText});

console.log("all data =" +  this.state.items);
  };

  onChangeAddInvitee =(e) => {
      this.setState({invitee: e.target.value});
  };

  Delete = (id) => {
      console.log("delete" + id);
      this.state.items.splice(id,1);
      this.setState({items:this.state.items});
      console.log(this.state.items);
  };


  handleValidate17= () =>{
    var x17= document.getElementById("invitees").value;
    const num =/[0-9]+/g;
    if(x17=="" || !num.test(x17))
    {
      document.getElementById("invitees").style.borderColor="red";
    }
    else{
      document.getElementById("invitees").style.borderColor="green";
      return 1;
    }
  };

  handleValidate18= () =>{
    var x18= document.getElementById("inviteeName").value;
    const num =/[0-9]+/g;
    const spcl =/[^a-zA-Z0\\s]/;
    if(x18=="" ||num.test(x18) || spcl.test(x18))
    {
      document.getElementById("inviteeName").style.borderColor="red";
    }
    else{
      document.getElementById("inviteeName").style.borderColor="green";
      return 1;
    }
  };

  handleValidate= () => {
   if(this.handleValidate17()==1 && this.handleValidate18()==1)
   {
     this.setState({check:false});
   }
   else {
     this.setState({check:true});
   }
};

  handleEigthClick = () => {

    let x ={
    ReceiverId:  document.getElementById('inviteeName').value,
    EventType: $('input[name=shipSpeed]:checked').val()
   };
   console.log(x.rates);
   $.ajax({
     url:'/addinvitees',
     type:'get',
     dataType:'json',
     data: x,
     success:function(data)
     {
       console.log('data');
       console.log(data);
     }.bind(this)
    });
  };

  handleSendInvite = () => {
   $.ajax({
     url:'/sendInvitation',
     type:'get',
     dataType:'json',
     success:function(data)
     {
       console.log('data');
       console.log(data);
     }.bind(this)
    });
  };

  render() {
    return (
       <div>
       <div className='col-xs-12'>
       <Paper style={styles.paper}>
       <Form horizontal style={{fontSize:'12px'}}>
       <FormGroup bsSize='small' style={styles.FormGroup}>
       <Col componentClass={ControlLabel} xs={4}>
       Event Type
       </Col>
       <Col xs={8}>
       <RadioButtonGroup name="shipSpeed" valueSelected="Open" id="eventType">
       <RadioButton
         value="Open"
         label="Open"
         name="shipSpeed"
         style={styles.radioButton}
         iconStyle={{fill: '#FFD93A'}}
       />
       <RadioButton
         value="Invite Only"
         label="Invite Only"
         name="shipSpeed"
         style={styles.radioButton}
         iconStyle={{fill: '#FFD93A'}}
       />
       </RadioButtonGroup>
       </Col>
       </FormGroup>
       <FormGroup bsSize='small' style={styles.FormGroup}>
       <Col componentClass={ControlLabel} xs={4}>
       Number Of Invitees
       </Col>
       <Col xs={8}>
       <FormControl type="text" id="invitees" placeholder="Only Numbers" />
       </Col>
       </FormGroup>
       <FormGroup bsSize='small' style={styles.FormGroup}>
       <Col componentClass={ControlLabel} xs={4}>
       Invitee Name
       </Col>
       <Col xs={8}>
       <FormControl type="text" id="inviteeName"  onChange= {this.onChangeAddInvitee} value={this.state.invitee} placeholder="Only Alphabets"/>
       </Col>
       <Col xs={2}>
       </Col>
       </FormGroup>
       <FormGroup bsSize='small'style={styles.FormGroup}>
       <Col componentClass={ControlLabel} xs={4}>
       Invitee List
       </Col>
       <Col xs={8}>
       <FormControl type="text"/>
       </Col>
       </FormGroup>
       </Form>
       </Paper>
       <InviteeList items={this.state.items}
       itemDelete={this.Delete} />
       <Button bsSize='small' style={styles.addbutton} onClick={this.handleSubmit} onTouchTap={this.handleEigthClick}>Add More</Button>
       <Button bsSize='small' style={styles.button1} onClick={this.handleClick} onTouchTap={this.handleSendInvite}>Send</Button>
    </div>
    </div>
    );
  }
}

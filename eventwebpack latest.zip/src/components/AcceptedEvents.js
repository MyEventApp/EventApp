import React, { Component} from 'react';
import { Button,Form,FormGroup,FormControl,Col,ControlLabel } from 'react-bootstrap';
import {Link} from 'react-router-dom';
import {Card,CardHeader, CardText} from 'material-ui/Card';
import Dialog from 'material-ui/Dialog';
import backbutton from '../images/back-button.png';
import Modal from './Modal';

const styles = {
  button:{
    background: '#FFD84A',
    marginRight: '5px',
  },
  sendbutton:{
    background: '#FFD84A',
    marginLeft: '5px',
  },
  card:{
    padding:'8px',
    border:'1px solid',
    marginTop:'7px',
    borderRadius: '7px',
    borderColor:'#BDC4C7',
    background:'#FFD84A',
  },
};

class AcceptedEvents extends Component {
  constructor(props) {
    super(props);
    this.state = {open: false};
  };

  handleOpen = () => this.setState({open: true});

  handleClose = () => this.setState({open: false});

  handleChange = () => {
  document.getElementById("button1").style.backgroundColor="#FFD93A";
  document.getElementById("button2").style.backgroundColor="#E0E0E0";
};

  handleChange1 = () => {
  document.getElementById("button1").style.backgroundColor="#E0E0E0";
  document.getElementById("button2").style.backgroundColor="#FFD93A";
};

  render() {
    const actions = [
      <Button active bsSize='small'onTouchTap={this.handleClose}>Cancel</Button>,
      <Button active bsSize='small' style={styles.sendbutton} >Send</Button>]
   return (
  <div className='col-xs-12 section'>
  <div className='row'>
  <div className='col-xs-2'>
  <Link to='/home'>
  <p><img src={backbutton} style={{width:'70%',marginTop:"5px"}}/></p>
  </Link>
  </div>
  <div className='col-xs-8'>
  <center><h4><b>My Events</b></h4></center>
  </div></div>
  <div className='row' >
    <div className='col-xs-6'>
      <Button block active id="button1" bsSize='small' style={styles.button} onClick={this.handleChange}>Accepted</Button>
    </div>
    <div className='col-xs-6'>
    <Link to='/myevents'>
      <Button block active id="button2" bsSize='small'  onClick={this.handleChange1}>Created</Button>
    </Link>
    </div>
  </div>

 <Card style={{borderRadius:'7px'}}>
  <CardHeader title="Launch Event" showExpandableButton={true} onTouchTap={this.handleOpen} style={styles.card} />
  </Card>
   <Dialog
         modal={true}
         open={this.state.open}
         actions={actions}
         onRequestClose={this.handleClose}
       >
<Modal/>
       </Dialog>


  </div>
);
}
}
export default AcceptedEvents;

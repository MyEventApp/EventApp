import React from 'react';
import {Collapse} from 'react-collapse';
import Paper from 'material-ui/Paper';
import backbutton from '../images/back-button.png';
import {Button} from 'react-bootstrap';
import { Form,FormGroup,FormControl,Col,ControlLabel } from 'react-bootstrap';
import {ContactPersonList} from './List.js';
import $ from 'jquery';



const styles = {
  paper:{
    background:'#E0E0E0',
    height: '100%',
    width: '100%',
    border:'1px solid',
    marginTop:'11px',
    marginBottom:'11px',
    borderRadius: '13px',
    borderColor:'#BDC3C7',
  },
  heading:{
    marginLeft: '25px',
  },

  headline: {
    fontSize: 24,
    paddingTop: 16,
    marginBottom: 12,
    fontWeight: 400,
  },

  FormGroup:{
   margin: '0px',
   marginTop: '10px',
   marginBottom: '10px'
  },
  button1:{
    background: '#FFD93A ',
    float:'right'
  },
  addbutton:{
    marginRight:'10px',
    float:'right'
  },
};

var addmore = {};

export default class CreateEvent4 extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      slideIndex:0,
      agendaName: [],
      personName: '',
      emailId: '',
      contact: '',
      open: true,
      items: [],
      id : 0,
      check:true
 };
  };

  onDrop(files) {
    this.setState({
      files
    });
  };

  handleClick = () => {
    const {slideIndex} = this.state;
    if(slideIndex<7){
    this.setState({
      slideIndex: slideIndex+1,
    });};
  };

  handleSubmit =(e) => {

    addmore[this.state.personName]=this.state.emailId;
    e.preventDefault();
    console.log("allow");

    this.setState({id:this.state.id+1});
    console.log("state id value is =" + this.state.id);

    var nextItems = this.state.items.concat({personName: this.state.personName,
                                                emailId: this.state.emailId,
                                                contact: this.state.contact,
                                                id:this.state.id}
                                              );
                                              console.log("nextitems = "+ nextItems.personName);
      var nextText = '';
      this.setState({items: nextItems, personName: nextText, emailId: nextText, contact: nextText});

console.log("all data =" +  this.state.items);
  };

  onChangePersonName =(e) => {
      this.setState({personName: e.target.value});
  };

  onChangeEmailId =(e)=> {
      this.setState({emailId: e.target.value});
  };

  onChangeContact =(e) => {
      this.setState({contact: e.target.value});
  };

  handleValidate10= () =>{
      var x10= document.getElementById("personName").value;
      const num =/[0-9]+/g;
      const spcl =/[^a-zA-Z0\\s]/;
      if(x10=="" || num.test(x10) || spcl.test(x10))
      {
        document.getElementById("personName").style.borderColor="red";
      }
      else{
        document.getElementById("personName").style.borderColor="green";
        return 1;
      }
    };

    handleValidate11= () =>{
      var x11= document.getElementById("personEmail").value;
      const email = /^[a-z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*)?@[a-z][a-zA-Z-0-9]*\.[a-z]+(\.[a-z]+)?$/;
      if(x11=="" || !email.test(x11))
      {
        document.getElementById("personEmail").style.borderColor="red";
      }
      else{
        document.getElementById("personEmail").style.borderColor="green";
        return 1;
      }
    };

    handleValidate12= () =>{
      var x12= document.getElementById("phone").value;
      const num =/[0-9]+/g;
      if(x12=="" || !num.test(x12)|| x12.length<3)
      {
        document.getElementById("phone").style.borderColor="red";
      }
      else{
        document.getElementById("phone").style.borderColor="green";
         return 1;
      }
    };

    handleValidate= () => {
       if(this.handleValidate10()==1 && this.handleValidate11()==1 && this.handleValidate12()==1)
       {
         this.setState({check:false});
       }
       else {
         this.setState({check:true});
       }
    };

    Delete = (id) => {
        console.log("delete" + id);
        this.state.items.splice(id,1);
        this.setState({items:this.state.items});
        console.log(this.state.items);
    };


    handleFourthClick = () => {
      let x ={
      Name:  this.state.personName,
      EmailId: this.state.emailId,
      ContactNumber: this.state.contact,
     };
    console.log(x);
     $.ajax({
       url:'/contactpersonform',
       type:'get',
       dataType:'json',
       data: x,
       success:function(data)
       {
         console.log('data');
         console.log(data);
       }.bind(this)
     });
    };

  render() {
    return (
        <div className='col-xs-12'>
        <ContactPersonList items={this.state.items}
        itemDelete={this.Delete} />

        <Paper style={styles.paper} onTouchTap={this.handleValidate}>
             <Form horizontal style={{fontSize:'12px'}}>
               <FormGroup bsSize='small' style={styles.FormGroup}>
                 <Col componentClass={ControlLabel} xs={4}>
                   Person Name
                 </Col>
                 <Col xs={8}>
                 <FormControl type="text" id="personName" onBlur={this.handleValidate10} onChange={this.onChangePersonName} placeholder="Only Alphabets" value={this.state.personName} />
                 </Col>
               </FormGroup>
               <FormGroup bsSize='small' style={styles.FormGroup}>
                 <Col componentClass={ControlLabel} xs={4}>
                   Email ID
                 </Col>
                 <Col xs={8}>
                 <FormControl type="email" id="personEmail" onBlur={this.handleValidate11} onChange={this.onChangeEmailId} placeholder="e.g. abcdef@xyz.com" value={this.state.emailId} />
                 </Col>
               </FormGroup>
               <FormGroup bsSize='small'style={styles.FormGroup}>
                 <Col componentClass={ControlLabel} xs={4}>
                Contact
                 </Col>
                 <Col xs={8}>
                  <FormControl type="number" id="phone" onBlur={this.handleValidate12} onChange={this.onChangeContact} placeholder="Only Numbers" value={this.state.contact} />
                 </Col>
               </FormGroup>
            </Form>
          </Paper>
          <Button bsSize='small' disabled={this.state.check} style={styles.button1} onClick={this.handleClick} onTouchTap={this.handleFourthClick}>Save and Next</Button>
          <Button bsSize='small' style={styles.addbutton} onClick={this.handleSubmit} onTouchTap={this.handleFourthClick}>Add More</Button>
        </div>
    );
  }
}

import React, { Component} from 'react';
import {Link} from 'react-router-dom';
import FlatButton from 'material-ui/FlatButton';
import RaisedButton from 'material-ui/RaisedButton';
import Dialog from 'material-ui/Dialog';
import {GridList, GridTile} from 'material-ui/GridList';
import IconButton from 'material-ui/IconButton';
import backbutton from '../images/back-button.png';
import Img1 from '../images/eventt-image1.png';
import Img2 from '../images/eventt-image2.png';
import Img3 from '../images/eventt-image3.png';
import Img4 from '../images/eventt-image4.png';
import '../css/style.css';
import $ from 'jquery';

const styles = {
  root: {
    display: 'flex',
    flexWrap: 'wrap',
    justifyContent: 'space-around',
  },
  gridList: {
    marginTop: '5px',
    overflowY: 'auto',
  },
};

const tilesData = [
 {
   img: Img3,
   title: 'Image1',
   index: 1,
 },
 {
   img: Img1,
   title: 'Image2',
   index: 2,
 },
 {
   img: Img2,
   title: 'Image3',
   index: 3,
 },
 {
   img: Img4,
   title: 'Image4',
   index: 4,
 }
];

class Gallery extends Component  {
  state = {
    open: false,
  };

  handleOpen = () => {
    this.setState({open: true});
  };
  handleClose = () => {
    this.setState({open: false});
  };

  handleImg = () =>{
  var img = $('.myImg');
  var modal = document.getElementById('myModal');
  var modalImg = $("#img01");
  var captionText = document.getElementById("caption");
  $('.myImg').click(function(){
      modal.style.display = "block";
      var newSrc = this.src;
      modalImg.attr('src', newSrc);
      captionText.innerHTML = this.alt;
  });
};
handleSpan = () =>{
  var span =document.getElementsByClassName("close")[0];
  document.getElementById('myModal').style.display='none';
};

  render() {
    return (
 <div className='col-xs-12 section'>
 <div className='row'>
 <div className='col-xs-2'>
 <Link to={'/details/'+JSON.parse(sessionStorage.Id)}>
 <p><img src={backbutton} style={{width:'70%',marginTop:"5px"}}/></p>
 </Link>
 </div>
 <div
  className='col-xs-8'>
 <center><h4><b>Gallery</b></h4></center>
 </div>
 </div>

 <div style={styles.root}>
 <GridList
   cellHeight={180}
   style={styles.gridList}
 >
     {tilesData.map((tile) => (
     <GridTile
       key={tile.index}
       title={tile.title}
     >
       <img className="myImg" onClick={this.handleImg} src={tile.img} alt={tile.title} value={tile.index} />
     </GridTile>
   ))}
 </GridList>
 </div>
 <div id="myModal" className="modal">
<span className="close" onClick={this.handleSpan} >&times;</span>
<img className="modal-content" id="img01" />
<div id="caption"></div>
</div>
 </div>

);
     }
   }

export default Gallery;

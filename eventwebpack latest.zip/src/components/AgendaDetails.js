import React, { Component} from 'react';
import {Link, Redirect} from 'react-router-dom';
import TinyMCE from 'react-tinymce';
import Paper from 'material-ui/Paper';
import { Button } from 'react-bootstrap';
import Avatar from 'material-ui/Avatar';
import Dialog from 'material-ui/Dialog';
import calendar from '../images/calender.png';
import location from '../images/location.png';
import backbutton from '../images/back-button.png';
import Leadphoto from '../images/photo1.png';
import Speakerphoto from '../images/download1.jpg';
import notes from '../images/notes.png';
import $ from 'jquery';
var speakerData=[];

const styles={
 paper:{
     background: '#FFD93A ',
     height: '100%',
     border:'1px solid',
     marginTop: '4px',
     marginBottom: '2px',
     borderColor:'#BDC3C7 ',
   },
   heading:{
     marginLeft:"60px",
   },
   time:{
     marginTop:"31px"
   }
 };

 class Editor extends Component {
  state = {
     open: true,

   };
 handleEditorChange = (e) => {
       console.log('Content was updated:', e.target.getContent());
     }
 handleClose = () => {
         this.setState({open: false});
       };

render() {
 return (
   <Dialog modal={false} open={this.state.open} onRequestClose={this.handleClose}>
   <TinyMCE
       content="<p>This is the initial content of the editor</p>"
       config={{
         plugins: 'link image code',
         toolbar: 'undo redo | bold italic | alignleft aligncenter alignright | code',
       }}
       onChange={this.handleEditorChange}

     />
     </Dialog>
 )};
};

// export class AgendaDetailData extends Component {
//   render() {
//
//
//     var agendaDetail = this.props.agendaDetail.map(function(data) {
//           return (
//             <AgendaDetails key={data.AgendaId}
//             AgendaName={data.AgendaName} Date={data.Date} StartTime={data.StartTime} EndTime={data.EndTime} Venue={data.Venue} EventId={data.EventId}
//             AgendaId={data.AgendaId} Description={data.Description} Lead={data.LeadName} Designation={data.Designation} Email={data.EmailId} />
//           );
//         }.bind(this));
//     return(
//       <div>{agendaDetail}</div>
//     )}
// };

export default class AgendaDetails extends Component  {

  constructor(props) {
    super(props);
    this.state={open:false,
    scheduleData: [],
    redirect:false
  };
  }

  handleClick = (e) => {
    e.preventDefault();
   this.setState({open: !this.state.open})
  }

  changeText = () =>
 {
   if (document.getElementById("message1").innerHTML=="+ Add to my Schedule") {
     var x={
       AgendaId:this.props.AgendaId
     };
  //   this.setState({redirect:true});
     $.ajax({
       url:'/scheduleData',
       type:'GET',
       dataType:'json',
       data: x,

       success:function(data)
       {
         console.log('data from server to schedulepage');
         console.log(data);
       }.bind(this)
     });

       document.getElementById("message1").innerHTML="- Remove from my Schedule";
   }
   else if (document.getElementById("message1").innerHTML=="- Remove from my Schedule"){
     var y={
       AgendaId:this.props.AgendaId
     };
  //   this.setState({redirect:true});
     $.ajax({
       url:'/deleteSchedule',
       type:'GET',
       dataType:'json',
       data: y,

       success:function(data)
       {
         console.log('data from server to schedulePage');
         console.log(data);
       }.bind(this)
     });
       document.getElementById("message1").innerHTML="+ Add to my Schedule";
   }
   }

  componentWillMount=()=> {
  sessionStorage.AgendaId=JSON.stringify(this.props.agendaDetail.AgendaId);
   var aId= JSON.parse(sessionStorage.AgendaId);
   console.log(aId);
 var speakers =JSON.parse(sessionStorage.speakers);
 console.log(speakers.length);
 for(var i=0;i<speakers.length;i++)
 {
  sessionStorage.AId = JSON.stringify(speakers[i].AgendaId);
  var id=JSON.parse(sessionStorage.AId);
  console.log(id);
  if(aId==id){
    console.log('hiiihjj');
    speakerData=speakers[i];
    console.log(speakerData);
    break;
    }
  else{
    console.log('elsegvh');
  }
 }
 }

 render() {
     console.log(this.props.agendaDetail);
  //  if(this.state.redirect==true)
  //  {
  //    return <Redirect push to ={"/schedule/" + this.props.AgendaId}/>;
  //  }
 return (
   <div className='col-xs-12 section'>
   <div className='row'>
   <div className='col-xs-2'>
   <Link to={'/agendalist/'+this.props.agendaDetail.EventId}>
   <img src={backbutton} style={{width:'70%',marginTop:"5px"}}/>
   </Link>
   </div>
   <div className='col-xs-8'>
   <center><h4><b>Agenda</b></h4></center>
   </div>
   <div className='col-xs-2'>
   <img src={notes} style={{width:'70%',marginTop:"5px",marginLeft:'8px'}} onClick={this.handleClick.bind(this)}/>
    {this.state.open && < Editor / >}
   </div>
   </div>

   <Paper zDepth={1} rounded={true} style={styles.paper} >
   <center><p style={styles.content}><strong>{this.props.agendaDetail.AgendaName}</strong></p>
   <p style={{fontSize:"12px"}}><img src={calendar} style={{width:'8%'}}/>>{this.props.agendaDetail.Date} @ {this.props.agendaDetail.StartTime} to {this.props.agendaDetail.EndTime}</p>
   <p style={{fontSize:"12px"}}><img src={location} style={{width:'8%'}}/>{this.props.agendaDetail.Venue}</p> </center>
   </Paper>
   <center>
   <p id="message1" style={{color:'#424242', fontWeight:'bold'}} onClick={this.changeText}>+ Add to my Schedule</p>
   </center>
   <Paper zDepth={1} rounded={true} style={{borderRadius:"7px"}}>
   <h5 style={{background:'#FFD93A ',borderRadius:"6px",padding:"6px"}}><strong>Overview</strong></h5>
   <p style={{paddingLeft: '6px'}}>{this.props.agendaDetail.Description}</p>
   </Paper>
   <Paper zDepth={1} rounded={true} style={{borderRadius:"7px",background:'#E0E0E0 ',}}>
   <h5 style={{background:'#FFD93A ',borderRadius:"6px",padding:"6px"}}><strong>Speakers</strong></h5>
   <Avatar src={Speakerphoto} style={{marginTop:"6px",marginLeft:'5px'}}/>
   <p style={{marginTop:"-50px",marginLeft:"60px"}}>{speakerData.Name}<br></br>
   {speakerData.Designation}<br></br>
   {speakerData.EmailId}</p>
   </Paper>
</div>
 );
}
}

import React, { Component} from 'react';
import {Link} from 'react-router-dom';
import Paper from 'material-ui/Paper';
import Avatar from 'material-ui/Avatar';
import img1 from '../images/download1.jpg';
import backbutton from '../images/back-button.png';
import Edit from 'material-ui/svg-icons/image/edit';
import '../css/style.css';

const styles={

profilepaper:{
    background:'#424242 ',
     height: '100%',
     marginBottom:'7px',
},
paper1:{
    background:'#FFD93A ',
    height:'100%',
    border:'1px solid',
    borderColor:'#BDC3C7 ',
    borderRadius:'7px'

},
paper:{
    height: '100%',
    border:'1px solid',
    marginBottom:'7px',
    borderColor:'#BDC3C7 ',
    borderRadius:'7px'

  },
  content:{
    marginLeft:'6px',
  },
  heading:{
    marginLeft:"35px",
    color: '#FFFFFF '
  },
  time:{
    marginTop:"31px"
  },
  name:{
    color:'#FFFFFF '
  }
  };
  export class SponsorDetailsData extends Component {
    render() {

      console.log(this.props.sponsorDetails);

      var sponsorDetails = this.props.sponsorDetails.map(function(data) {
            return (
              <SponsorDetails key={data.SponsorsId} EventId={data.EventId}
              SponsorName={data.SponsorName} EmailId={data.EmailId} SponsorsId={data.SponsorsId} Website={data.Website} Contact={data.ContactNumber} Description={data.Description}/>
            );
          }.bind(this));
      return(
       <div>
       {sponsorDetails}
       </div>
      );
    }
  }

export class SponsorDetails extends Component  {
render() {
return(
 <div className='col-xs-12 section'>
 <Paper zDepth={1} rounded={true} style={styles.profilepaper} >
 <div className='row'>
 <div className='col-xs-3'>
 <Link to={'/sponsorlist/'+this.props.EventId}>
 <p><img src={backbutton} style={{width:'40%',marginTop:"5px"}}/></p>
 </Link>
 </div>
 </div>

 <div className='row'>
 <div className='col-xs-12'>
 <center>
 <Avatar src={img1} size={150}/>
 </center>
 </div>
 </div>

 <div className='row'>
 <div className='col-xs-12'>
 <center>
 <p style={styles.name}><strong>{this.props.SponsorName}</strong></p>
 <p style={styles.name}>{this.props.Website}</p>
 </center>
 </div>
 </div>
 </Paper>

 <div className='row'>
 <div className='col-xs-12'>
 <Paper zDepth={2} rounded={true} style={{borderRadius:"7px"}}>
 <h5 style={{background:'#FFD93A ', borderRadius:'6px', padding:'6px'}}><strong>About</strong></h5>
 <div style={{margin:'6px'}}>
 <p>{this.props.Description}</p>
 </div>
 </Paper>
 </div>
 </div>

 <div className='row'>
 <div className='col-xs-12'>
 <Paper zDepth={2} rounded={true} style={{borderRadius:"7px"}}>
 <h5 style={{background:'#FFD93A ', borderRadius:'6px', padding:'6px'}}><strong>Contact Details</strong></h5>
 <div style={{margin:'6px'}}>
 <p>{this.props.EmailId}</p>
 <p>{this.props.Contact}</p>
 </div>
 </Paper>
 </div>
 </div>
</div>
);
}
}

import React from 'react';
import Dropzone from 'react-dropzone';
import {Collapse} from 'react-collapse';
import Paper from 'material-ui/Paper';
import {Button} from 'react-bootstrap';
import { Form,FormGroup,FormControl,Col,ControlLabel } from 'react-bootstrap';
let dropzoneRef;

const styles = {
  paper:{
    background:'#E0E0E0',
    height: '100%',
    width: '100%',
    border:'1px solid',
    marginTop:'11px',
    marginBottom:'11px',
    borderRadius: '13px',
    borderColor:'#BDC3C7',
  },
  heading:{
    marginLeft: '25px',
  },
  headline: {
    fontSize: 24,
    paddingTop: 16,
    marginBottom: 12,
    fontWeight: 400,
  },
  uploadbutton:{
   marginRight:'10px',
   float:'right'
 },
  FormGroup:{
   margin: '0px',
   marginTop: '10px',
   marginBottom: '10px'
  },
  button1:{
    background: '#FFD93A ',
    float:'right'
  },
};

export default class CreateEvent6 extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      slideIndex:0,
      open: true,
      accepted: [],
      agendaName: [],
      items : [],
      sponsorName: '',
      companyLogo: '',
      emailId: '',
      contact: '',
      description: '',
      websiteUrl: '',
      id:0,
   };
  }

  onDrop(files) {
    this.setState({
      files
    });
  };

  handleClick = () => {
    const {slideIndex} = this.state;
    if(slideIndex<7){
    this.setState({
      slideIndex: slideIndex+1,
    });};
  };

  render() {
    return (
    <div>
    <Paper style={styles.paper}>
    <Form horizontal style={{fontSize:'12px'}}>
     <FormGroup bsSize='small' style={styles.FormGroup}>
       <Col componentClass={ControlLabel} xs={12}>
         Document
       </Col>
       <Col xs={8}>
       <Dropzone ref={(node) => { dropzoneRef = node; }} onDrop={(accepted, rejected) => { this.setState({accepted}) }} style={{width:'100px',height:'30px',border:'1px solid',borderRadius:'2px',borderColor:'#BDC3C7',background:'#ffffff'}}>
           <p>{this.state.accepted.length} files selected</p>
       </Dropzone>
       </Col>
       <Col xs={4}>
        <Button bsSize='small' style={styles.button1} onClick={() => { dropzoneRef.open() }}>Browse</Button>
       </Col>
       </FormGroup>
       <FormGroup bsSize='small' style={styles.FormGroup}>
         <Col componentClass={ControlLabel} xs={12}>
         <Button bsSize='small' style={styles.button1} >Add More</Button>
         </Col>
       </FormGroup>
    </Form>
    </Paper>
    <Button bsSize='small' style={styles.button1} onClick={this.handleClick}>Save and Next</Button>
    <Button bsSize='small' style={styles.uploadbutton}>Upload</Button>
    </div>
    );
  }
}

import React from 'react';
import $ from 'jquery';
import {Collapse} from 'react-collapse';
import Dropzone from 'react-dropzone';
import DateTimeField from 'react-bootstrap-datetimepicker';
import DatePicker from 'react-bootstrap-date-picker';
import TimePicker from 'react-bootstrap-time-picker';
import TimezonePicker from 'react-bootstrap-timezone-picker';
import 'react-bootstrap-timezone-picker/dist/react-bootstrap-timezone-picker.min.css';
import Paper from 'material-ui/Paper';
import backbutton from '../images/back-button.png';
import {Button} from 'react-bootstrap';
import { Form,FormGroup,FormControl,Col,ControlLabel } from 'react-bootstrap';
let dropzoneRef;

const styles = {
    paper:{
      background:'#E0E0E0',
      height: '100%',
      width: '100%',
      border:'1px solid',
      marginTop:'11px',
      marginBottom:'11px',
      borderRadius: '13px',
      borderColor:'#BDC3C7',
    },
    heading:{
      marginLeft: '25px',
    },
    headline: {
      fontSize: 24,
      paddingTop: 16,
      marginBottom: 12,
      fontWeight: 400,
    },
    slide: {
      padding: 20,
    },
    FormGroup:{
     margin: '0px',
     marginTop: '10px',
     marginBottom: '10px'
    },
    button1:{
      background: '#FFD93A ',
      float:'right'
    },
    addbutton:{
      marginRight:'10px',
      float:'right'
    },
    uploadbutton:{
      marginRight:'10px',
      float:'right'
    },
    radioButton: {
      marginBottom: '16px',
    },
  };

export default class CreateEvent1 extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      slideIndex:0,
      currentValue:'',
      open: true,
      accepted: [],
      format: "DD/MM/YYYY HH:mm",
      dateformat: "DD/MM/YYYY",
      timeformat: "HH:mm",
      dateTime:"22/08/2017 12:00",
      dateTime1:"22/09/2017 12:00",
      inputFormat: "DD/MM/YYYY HH:mm",
      date: '22/08/17',
      startTime: '00:00',
      endTime: '00:00',
      agendaName: [],
      agendavalue: [],
      check:true,
     };
  }

  handleClick = () => {
    const {slideIndex} = this.state;
    if(slideIndex<7){
    this.setState({
      slideIndex: slideIndex+1,
    });};
  };

  handleFirstClick = () => {
  let x ={
  EventName: document.getElementById('eventName').value,
  CreatorName: document.getElementById('owner').value,
  CompanyName: document.getElementById('company').value,
  StartDateTime: this.state.dateTime,
  EndDateTime: this.state.dateTime1,
  Location: document.getElementById('location').value,
  TimeZone: this.state.currentValue,
  Description: document.getElementById('placeholder').value,
  };
  console.log(x.EndDateTime);
  $.ajax({
   url:'/eventform',
   type:'get',
   dataType:'json',
   data: x,
   success:function(data)
   {
     console.log('data');
     console.log(data);
   }.bind(this)
  });
  };

  handleChange0 = (newValue) => this.setState({ currentValue: newValue });

  handleStartDateTime = (newDate) => this.setState({ dateTime: newDate});

  handleEndDateTime = (newDate1) => this.setState({ dateTime1: newDate1 });

  onDrop(files) {
    this.setState({
      files
    });
  };



  handleValidate1= () =>{
       var x1= document.getElementById("eventName").value;
       if(x1=="")
       {
         document.getElementById("eventName").style.borderColor="red";
       }
       else{
         document.getElementById("eventName").style.borderColor="green";
        return 1;
      }
    };

    handleValidate2= () =>{
    var x2= document.getElementById("owner").value;
     const num =/[0-9]+/g;
     const spcl =/[^a-zA-Z0\\s]/;
    if(x2=="" || num.test(x2) || spcl.test(x2))
    {
      document.getElementById("owner").style.borderColor="red";
    }
    else{
      document.getElementById("owner").style.borderColor="green";
      return 1;
    }
  };

  handleValidate3= () =>{
    var x3= document.getElementById("location").value;
    if(x3=="" || x3.length>20)
    {
      document.getElementById("location").style.borderColor="red";
    }
    else{
      document.getElementById("location").style.borderColor="green";
      return 1;
    }
  };

  handleValidate4= () =>{
    var x4= document.getElementById("placeholder").value;
    if(x4=="" || x4.length>150)
    {
      document.getElementById("placeholder").style.borderColor="red";
    }
    else {
      document.getElementById("placeholder").style.borderColor="green";
      return 1;
    }
  };

  handleValidate= () => {
     if(this.handleValidate1()==1 && this.handleValidate2()==1 && this.handleValidate3()==1 && this.handleValidate4()==1)
     {
       this.setState({check:false});
     }
     else {
       this.setState({check:true});
     }
  };


  render() {

    const {format, mode, inputFormat, dateformat, timeformat,dateTime,dateTime1,date,startTime,endTime,agendavalue} = this.state;
    return (
      <div>
      <Paper style={styles.paper} onTouchTap={this.handleValidate}>
      <Form horizontal style={{fontSize:'12px'}}>
       <FormGroup bsSize='small' style={styles.FormGroup}>
        <Col componentClass={ControlLabel} xs={4}>
         Event Name
        </Col>
        <Col xs={8}>
        <FormControl type="text" id="eventName" onBlur={this.handleValidate1} placeholder="Enter Text Here" defaultValue={this.props.EventName}/>
        </Col>
       </FormGroup>
       <FormGroup bsSize='small' style={styles.FormGroup}>
        <Col componentClass={ControlLabel} xs={4}>
         Owner
        </Col>
        <Col xs={8}>
        <FormControl type="text" id="owner" onBlur={this.handleValidate2} placeholder="Only Alphabets" defaultValue={this.props.Owner}/>
        </Col>
       </FormGroup>
       <FormGroup bsSize='small'style={styles.FormGroup}>
        <Col componentClass={ControlLabel} xs={4}>
        Company
        </Col>
        <Col xs={8}>
        <FormControl type="text" id="company" placeholder="Enter Text Here" defaultValue={this.props.Company}/>
        </Col>
       </FormGroup>
       <FormGroup bsSize='small'style={styles.FormGroup}>
        <Col componentClass={ControlLabel} xs={4}>
         Location
        </Col>
        <Col xs={8}>
        <FormControl type="text" id="location" onBlur={this.handleValidate3} placeholder="Not More Than 20 Words" defaultValue={this.props.Location}/>
        </Col>
       </FormGroup>
       <FormGroup bsSize='small'style={styles.FormGroup}>
        <Col componentClass={ControlLabel} xs={4}>
         Start Date & Time
        </Col>
        <Col xs={8}>
        <DateTimeField inputFormat={inputFormat} format={format} dateTime={dateTime} onChange={this.handleStartDateTime}/>
        </Col>
       </FormGroup>
       <FormGroup bsSize='small'style={styles.FormGroup}>
        <Col componentClass={ControlLabel} xs={4}>
         End Date & Time
        </Col>
        <Col xs={8}>
        <DateTimeField inputFormat={inputFormat} format={format} dateTime={dateTime1} onChange={this.handleEndDateTime}/>
        </Col>
       </FormGroup>
       <FormGroup bsSize='small'style={styles.FormGroup}>
        <Col componentClass={ControlLabel} xs={4}>
        TimeZone
        </Col>
        <Col xs={8}>
        <TimezonePicker
          absolute      = {false}
          id="timezone"
          placeholder   = "Select timezone..."
          onChange      = {this.handleChange0}
          defaultValue={this.props.TimeZone}
          style={{width:'100%'}}
        />
        </Col>
       </FormGroup>
       <FormGroup bsSize='small'style={styles.FormGroup}>
        <Col componentClass={ControlLabel} xs={4}>
        Description
        </Col>
        <Col xs={8}>
        <FormControl type="text" id="placeholder" placeholder="Not More Than 150 Words" onBlur={this.handleValidate4} defaultValue={this.props.Description}/>
        </Col>
       </FormGroup>
       <FormGroup bsSize='small'style={styles.FormGroup}>
       <Col componentClass={ControlLabel} xs={4}>
       Event Image
       </Col>
       <Col xs={5}>
       <Dropzone ref={(node) => { dropzoneRef = node; }} onDrop={(accepted, rejected) => { this.setState({accepted}) }} style={{width:'100px',height:'30px',border:'1px solid',borderRadius:'2px',borderColor:'#BDC3C7',background:'#ffffff'}}>
           <p>{this.state.accepted.length}files selected</p>
       </Dropzone>
       </Col>
       <Col xs={3}>
       <Button bsSize='small' style={styles.button1} onClick={() => { dropzoneRef.open() }}>Browse</Button>
       </Col>
       </FormGroup>
       </Form>
       </Paper>
       <Button bsSize='small' disabled={this.state.check} style={styles.button1} onClick={this.handleClick} onTouchTap={this.handleFirstClick}>Save and Next</Button>
       </div>
    );
  }
}

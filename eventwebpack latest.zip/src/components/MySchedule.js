import React, { Component} from 'react';
import {Link} from 'react-router-dom';
import Paper from 'material-ui/Paper';
import calendar from '../images/calender.png';
import location from '../images/location.png';
import backbutton from '../images/back-button.png';
import rightarrow from '../images/RIght-arrow-Icons.png';
import clock from '../images/clock.png';
import remove from '../images/subtraction.png';
import '../css/style.css';

const styles={
 paper:{
     background: '#FFD93A ',
     height: '100%',
     border:'1px solid',
     marginBottom:'11px',
     borderColor:'#BDC3C7 ',
   },
   content:{
     marginLeft:'6px',
   },
   heading:{
     marginLeft:"35px",
   },
   time:{
     marginTop:"31px"
   }
   };


export class MyScheduleData extends Component{
  render(){
    var scheduleData= this.props.scheduleData.map(function(data) {
            return (
              <MySchedule key={data.AgendaId}
              AgendaName={data.AgendaName} Date={data.Date} StartTime={data.StartTime} EndTime={data.EndTime} Venue={data.Venue} EventId={data.EventId}
              AgendaId={data.AgendaId} Description={data.Description} Lead={data.LeadName} Designation={data.Designation} Email={data.EmailId} />
            );
          }.bind(this));
      return(
        <div className='col-xs-12 section'>
        <div className='row'>
        <div className='col-xs-2'>
        <Link to='/home'>
        <p><img src={backbutton} style={{width:'70%',marginTop:"5px"}}/></p>
        </Link>
        </div>
        <div className='col-xs-8'>
        <center><h4><b>My Schedule</b></h4></center>
        </div>
        </div>
        {scheduleData}
        </div>
      )}
  }

export class MySchedule extends Component  {
 render() {
 return (
<div>
   <Paper zDepth={1} rounded={true} style={styles.paper}>
   <div className='row'>
   <div className='col-xs-10'>
   <p style={styles.content}><strong>{this.props.AgendaName}</strong></p>
   </div>
   <div className='col-xs-2'>
   <img src={remove} style={{width:'50%', marginLeft:'12px'}}/>
   </div>
   </div>
   <div className='row'>
   <div className='col-xs-12'>
   <p><img src={calendar} style={{width:'7%'}}/>{this.props.Date}</p>
   </div>
   </div>
   <div className='row'>
   <div className='col-xs-8'>
   <p><img src={clock} style={{width:'9%', marginLeft:'2px'}}/>{this.props.StartTime} to {this.props.EndTime}</p>
   </div>
   <div className='col-xs-2'>
   </div>
   <div className='col-xs-2'>
   <p><img src={rightarrow} style={{width:'50%',marginLeft:'12px'}}/></p>
   </div>
   </div>
   <div className='row'>
   <div className='col-xs-12'>
   <p><img src={location} style={{width:'7%'}}/>{this.props.Venue}</p>
   </div>
   </div>
  </Paper>
  </div>
 );
}
}

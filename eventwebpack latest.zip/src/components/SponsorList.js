import React, { Component} from 'react';
import {Link} from 'react-router-dom';
import Paper from 'material-ui/Paper';
import { Button } from 'react-bootstrap';
import Avatar from 'material-ui/Avatar';
import Speakerphoto1 from '../images/download1.jpg';
import backbutton from '../images/back-button.png';
import rightarrow from '../images/RIght-arrow-Icons.png';

const styles={
  paper:{
      background: '#FFD93A',
      borderRadius:"7px",
      height: '100%',
      marginBottom:'11px',
      borderColor:'#BDC3C7',
    },
  };
export class SponsorData extends Component {
  render() {
    console.log(this.props.sponsorList);
    var sponsorList = this.props.sponsorList.map(function(data) {
           return (

             <SponsorList key={data.SponsorsId} EventId={data.EventId}
             SponsorName={data.SponsorName} EmailId={data.EmailId} SponsorsId={data.SponsorsId}/>
           );
         }.bind(this));
     return(
       <div className='col-xs-12 section'>
         <div className='row'>
         <div className='col-xs-2'>
         <Link to={'/details/'+ JSON.parse(sessionStorage.Id)}>
         <p><img src={backbutton} style={{width:'70%',marginTop:"5px"}}/></p>
         </Link>
         </div>
         <div className='col-xs-8'>
         <center><h4><b>Sponsors</b></h4></center>
         </div>
         </div>
         {sponsorList}
         </div>
     );
   }
 };

export class SponsorList extends Component  {
render() {
return (
  <div>
<Paper zDepth={1} rounded={true} style={styles.paper}>
<div className='row'>
<div className='col-xs-2'>
<Avatar src={Speakerphoto1} style={{marginTop:"6px",marginLeft:"5px"}}/>
</div>
<div className='col-xs-8'>
<p>{this.props.SponsorName}<br></br>
{this.props.EmailId}</p>
</div>
<div className='col-xs-2'>
<Link to= {'/sponsordetails/'+this.props.SponsorsId}>
<p><img src={rightarrow} style={{width:'50%',marginTop:"15px"}}/></p>
</Link>
</div>
</div>
</Paper>
</div>
);
}
}

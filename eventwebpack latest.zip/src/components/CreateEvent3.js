import React from 'react';
import {Collapse} from 'react-collapse';
import Dropzone from 'react-dropzone';
import Paper from 'material-ui/Paper';
//import {Tabs, Tab} from 'material-ui/Tabs';
import backbutton from '../images/back-button.png';
import {Button} from 'react-bootstrap';
import { Form,FormGroup,FormControl,Col,ControlLabel } from 'react-bootstrap';
import RaisedButton from 'material-ui/RaisedButton';
import {SpeakerList} from './List.js';
import DropDownMenu from 'material-ui/DropDownMenu';
import MenuItem from 'material-ui/MenuItem';
let dropzoneRef;
import $ from 'jquery';



const styles = {
  paper:{
    background:'#E0E0E0',
    height: '100%',
    width: '100%',
    border:'1px solid',
    marginTop:'11px',
    marginBottom:'11px',
    borderRadius: '13px',
    borderColor:'#BDC3C7',
  },
  heading:{
    marginLeft: '25px',
  },

  headline: {
    fontSize: 24,
    paddingTop: 16,
    marginBottom: 12,
    fontWeight: 400,
  },
  FormGroup:{
   margin: '0px',
   marginTop: '10px',
   marginBottom: '10px'
  },
  button1:{
    background: '#FFD93A ',
    float:'right'
  },
  addbutton:{
    marginRight:'10px',
    float:'right'
  },
};


var addmore={};

export default class CreateEvent3 extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      slideIndex:0,
      open: true,
      accepted: [],
      agendaName: 'Event Created',
      speakerName: '',
      image:'',
      speakerEmailId: '',
      speakerDesignation: '',
      items: [],
      id : 0,
      value:'',
      itemNumber:[],
      check:true
      };
  }




  onDrop(files) {
    this.setState({
      files
    });
  };

  handleClick = () => {
    const {slideIndex} = this.state;
    if(slideIndex<7){
    this.setState({
      slideIndex: slideIndex+1,
    });};
  };

  handleSubmit =(e) => {
    addmore[this.state.agendaName]=this.state.speakerName;
    e.preventDefault();
    console.log("allow");
    this.setState({id:this.state.id+1});
    console.log("state id value is =" + this.state.id);

    var nextItems = this.state.items.concat({agendaName: 'this.state.agendaName',
                                                speakerName: this.state.speakerName,
                                                image: this.state.image,
                                                speakerEmailId: this.state.speakerEmailId,
                                                speakerDesignation: this.state.speakerDesignation,
                                                id:this.state.id}
                                              );
                                               console.log("agenda nextitems = ");
                                              console.log(nextItems);
      var nextText = '';
      this.setState({items: nextItems, agendaName: nextText, speakerName: nextText, image: nextText, speakerEmailId: nextText, speakerDesignation: nextText});

console.log("all data =" +  this.state.items);
  };

  onChangeAgendaName =(e) => {
      this.setState({agendaName: e.target.value});
  };

  onChangeSpeakerName =(e)=> {
      this.setState({speakerName: e.target.value});
      console.log("change"+this.state.speakerName);
  };

  onChangeImages =(e) => {
      this.setState({image: e.target.value});
  };

  onChangeEmailId =(e) => {
      this.setState({speakerEmailId: e.target.value});
  };

  onChangeDesignation =(e) => {
      this.setState({speakerDesignation: e.target.value});
  };


  Delete = (id) => {
      console.log("delete" + id);
      this.state.items.splice(id,1);
      this.setState({items:this.state.items});
      console.log(this.state.items);
  };


  handleValidate8= () =>{
    var x8= document.getElementById("emailId").value;
    const email = /^[a-z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*)?@[a-z][a-zA-Z-0-9]*\.[a-z]+(\.[a-z]+)?$/;
    if(x8=="" || !email.test(x8))
    {
      document.getElementById("emailId").style.borderColor="red";
    }
    else{
      document.getElementById("emailId").style.borderColor="green";
      return 1;
    }
  };

  handleValidate9= () =>{
    var x9= document.getElementById("designation").value;
    const num =/[0-9]+/g;
    const spcl =/[^a-zA-Z0\\s]/;
    if(x9=="" || num.test(x9) || spcl.test(x9) || x9.length>20)
    {
      document.getElementById("designation").style.borderColor="red";
    }
    else{
      document.getElementById("designation").style.borderColor="green";
       return 1;
    }
  };

  handleSpeakerNameValidation= () =>{
    var x19= document.getElementById("name").value;
    const num =/[0-9]+/g;
    const spcl =/[^a-zA-Z0\\s]/;
    if(x19=="" || num.test(x19) || spcl.test(x19))
    {
      document.getElementById("name").style.borderColor="red";
    }
    else{
      document.getElementById("name").style.borderColor="green";
      return 1;
    }
  };

  handleValidate= () => {
     if(this.handleValidate8()==1 && this.handleValidate9()==1 && this.handleSpeakerNameValidation()==1)
     {
       this.setState({check:false});
     }
     else {
       this.setState({check:true});
     }
  };

  handleThirdClick = () => {
    // var e= document.getElementById('agendaName1');
    // console.log('agenda name is');
    // console.log(e);
    // console.log(e);
    // console.log('data going to server after add click');
    // console.log(e[e.selectedIndex].text);
  //   let x ={
  //   AgendaName: e[e.selectedIndex].text,
  //   Name:  document.getElementById('name').value,
  //   EmailId: document.getElementById('emailId').value,
  //   Designation: document.getElementById('designation').value,
  //  };
  // console.log(x.AgendaName);
    let x ={
    AgendaName:this.state.value,
    Name:  this.state.speakerName,
    EmailId: this.state.speakerEmailId,
    Designation:  this.state.speakerDesignation,
   };
   console.log('data is');
   console.log(x.Name);
   $.ajax({
     url:'/speakerform',
     type:'get',
     dataType:'json',
     data: x,
     success:function(data)
     {
       console.log('data');
       console.log(data);
     }.bind(this)
   });
  };
   handleChange = (event, index, value) => this.setState({value});
cilck=()=>{
      this.props.agendaList.forEach((data,i)=>{
          this.state.itemNumber.push(<MenuItem value={data.AgendaName} key={i} primaryText={data.AgendaName} />);
      });
  
}

  render() {
       const {dateTime, inputFormat, inputFormat1, inputFormat2} = this.state;
    return (

        <div className='col-xs-12'>

          <SpeakerList items={this.state.items}
          itemDelete={this.Delete} />

          <Paper style={styles.paper} onTouchTap={this.cilck} onClick={this.handleValidate}>
            <Form horizontal style={{fontSize:'12px'}}>
            <FormGroup bsSize='small' style={styles.FormGroup}>
            <Col componentClass={ControlLabel} xs={4}>
              Agenda Name
            </Col>
            <Col xs={8}>
            <DropDownMenu maxHeight={300} value={this.state.value} onChange={this.handleChange}
          >
            {this.state.itemNumber}
      </DropDownMenu>
            </Col>
            </FormGroup>
            <FormGroup bsSize='small'style={styles.FormGroup}>
              <Col componentClass={ControlLabel} xs={4}>
               Speaker Name
              </Col>
              <Col xs={8}>
                <FormControl type="text" id="name" onBlur={this.handleSpeakerNameValidation} onChange={this.onChangeSpeakerName} placeholder="Only Alphabets" value={this.state.speakerName}/>
              </Col>
            </FormGroup>
            <FormGroup bsSize='small'style={styles.FormGroup}>
            <Col componentClass={ControlLabel} xs={4}>
            Image
            </Col>
            <Col xs={5}>
            <Dropzone ref={(node) => { dropzoneRef = node; }} onDrop={(accepted, rejected) => { this.setState({accepted}) }} style={{width:'100px',height:'30px',border:'1px solid',borderRadius:'2px',borderColor:'#BDC3C7',background:'#ffffff'}}>
                <p>{this.state.accepted.length}files selected</p>
            </Dropzone>
            </Col>
            <Col xs={3}>
            <Button bsSize='small' style={styles.button1} onClick={() => { dropzoneRef.open() }}>Browse</Button>
            </Col>
            </FormGroup>
            <FormGroup bsSize='small'style={styles.FormGroup}>
              <Col componentClass={ControlLabel} xs={4}>
               Speaker Email ID
              </Col>
              <Col xs={8}>
              <FormControl type="email" id="emailId" onBlur={this.handleValidate8} onChange={this.onChangeEmailId} placeholder="e.g abcdef@xyz.com" value={this.state.speakerEmailId}/>
              </Col>
            </FormGroup>
            <FormGroup bsSize='small'style={styles.FormGroup}>
              <Col componentClass={ControlLabel} xs={4}>
               Designation
              </Col>
              <Col xs={8}>
              <FormControl type="text" id="designation" onBlur={this.handleValidate9} onChange={this.onChangeDesignation} value={this.state.speakerDesignation}/>
              </Col>
            </FormGroup>
            </Form>
         </Paper>
         <Button bsSize='small' disabled={this.state.check} style={styles.button1} onClick={this.handleClick} onTouchTap={this.handleThirdClick}>Save and Next</Button>
        <Button bsSize='small' style={styles.addbutton} onClick={this.handleSubmit} onTouchTap={this.handleThirdClick}>Add More</Button>
      </div>
    );
  }
}

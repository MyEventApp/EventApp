import React, { Component} from 'react';
import {Link} from 'react-router-dom';
import Demo from '../images/Demo.png';
import SignIn from '../images/Sign-in.png';
import Logo from '../images/Event-app-2.png';
import '../css/style.css';

const styles = {
  heading:{
    marginTop: '100px',
    marginLeft:'100px',
  },
};

class Main extends Component  {

render(){
return(
 <div className='col-xs-12 section'>
 <div className='row'>
<center>
 <img src={Logo} style={{height:'60%', width:'60%', marginTop:'100px'}}/>
</center>
 </div>

 <div className='row'>
 <div className='col-xs-6'>
 <Link to='/demoevent'>
 <img src={Demo} style={{width:'30%',marginLeft:'50%',marginTop:'160px'}} />
 </Link>
 </div>
 <div className='col-xs-6'>
  <Link to='/login'>
 <img src={SignIn} style={{width:'30%',marginLeft:'20%',marginTop:'160px'}} />
 </Link>
 </div>
 </div>

 <div className='row'>
 <div className='col-xs-6'>
 <h5 style={{marginTop:'10px',marginLeft:'53%'}}><b>Demo</b></h5>
 </div>
 <div className='col-xs-6'>
 <h5 style={{marginTop:'10px',marginLeft:'10%'}}><b>Sign In/Out</b></h5>
 </div>
 </div>
 </div>
);
}
}

export default Main;

import React from 'react';
import ReactDOM from 'react-dom';
import {AgendaRow, SpeakerRow, ContactPersonRow, SponsorRow, InviteeRow} from './Row.js';


export class AgendaList extends React.Component{
    handleDel = (index) => {
        this.props.itemDelete(index);

    }
  render() {
    var listItems= [], me=this;
    this.props.items.map(function (item,i){
        listItems.push(<AgendaRow item={item} id={i} itemDelete={me.handleDel}/>)
    });
    return <ul style={{listStyle:"none"}}>{listItems}</ul>;
  }
}

export class SpeakerList extends React.Component{
    handleDel = (index) => {
        this.props.itemDelete(index);
    }
  render() {
    var listItems= [], me=this;
    this.props.items.map(function (item,i){
        listItems.push(<SpeakerRow item={item} id={i} itemDelete={me.handleDel}/>)
    });
    return <ul style={{listStyle:"none"}}>{listItems}</ul>;
  }
}

export class ContactPersonList extends React.Component{
    handleDel = (index) => {
        this.props.itemDelete(index);

    }
  render() {
    var listItems= [], me=this;
    this.props.items.map(function (item,i){
        listItems.push(<ContactPersonRow item={item} id={i} itemDelete={me.handleDel}/>)
    });
    return <ul style={{listStyle:"none"}}>{listItems}</ul>;
  }
}

export class SponsorList extends React.Component{
    handleDel = (index) => {
        this.props.itemDelete(index);

    }
  render() {
    var listItems= [], me=this;
    this.props.items.map(function (item,i){
        listItems.push(<SponsorRow item={item} id={i} itemDelete={me.handleDel}/>)
    });
    return <ul style={{listStyle:"none"}}>{listItems}</ul>;
  }
}

export class InviteeList extends React.Component{
    handleDel = (index) => {
        this.props.itemDelete(index);
    }
    
  render() {
    var listItems= [], me=this;
    this.props.items.map(function (item,i){
        listItems.push(<InviteeRow item={item} id={i} itemDelete={me.handleDel}/>)
    });
    return <ul style={{listStyle:"none"}}>{listItems}</ul>;
  }
}

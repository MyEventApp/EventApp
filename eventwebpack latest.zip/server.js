var express = require('express');
var app = express();
var bodyparser = require('body-parser');
var func = require('./server/profileData');

app.use(bodyparser.text({limit:'100mb'}));
app.use(bodyparser.urlencoded({limit:'100mb',extended:true}));

// webpack
const webpack = require('webpack');
const webpackDevMiddleware = require('webpack-dev-middleware');
const webpackConfig = require('./webpack.config');

// middlwares
app.use(webpackDevMiddleware(webpack(webpackConfig)));

app.use('/', express.static(__dirname + '/src'));
app.use(bodyparser.json());

app.get('/',function(req,res,err){
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "X-Requested-With");
    res.locals.message = err.message;
    res.locals.error = req.app.get('env') === 'development' ? err : {};

});

app.get('/login',function(req,res,err){
console.log("coming inside events API",req.body);
let loginData = req.body;
res.header("Access-Control-Allow-Origin", "*");
res.header("Access-Control-Allow-Headers", "X-Requested-With");
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};
   func.getLogin(loginData, function (res1) {
     console.log(res1);
         res.send(res1);
  });
});

app.get('/loginid',function(req,res,err){
console.log("coming inside events1 API");
let x = {LoginId: req.query.LoginId};
res.header("Access-Control-Allow-Origin", "*");
res.header("Access-Control-Allow-Headers", "X-Requested-With");
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};
   func.getLoginId(x, function (res1) {
     console.log(res1);
         res.send(res1);
  });
});

app.get('/profile',function(req,res,err){
console.log("coming inside events API",req.body);
let profileData = req.body;
res.header("Access-Control-Allow-Origin", "*");
res.header("Access-Control-Allow-Headers", "X-Requested-With");
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};
   func.getProfile(profileData, function (res1) {
     console.log(res1);
         res.send(res1);
  });
});

app.get('/notifications',function(req,res,err){
console.log("coming inside events API",req.body);
let notifications = req.body;
res.header("Access-Control-Allow-Origin", "*");
res.header("Access-Control-Allow-Headers", "X-Requested-With");
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};
   func.getNotifications(notifications, function (res1) {
     console.log(res1);
         res.send(res1);
  });
});

app.get('/events',function(req,res,err){
console.log("coming inside events API",req.body);
let eventData = req.body;
res.header("Access-Control-Allow-Origin", "*");
res.header("Access-Control-Allow-Headers", "X-Requested-With");
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};
   func.getEvents(eventData, function (res1) {
     console.log(res1);
         res.send(res1);
  });
});

app.get('/adminevents',function(req,res,err){
console.log("coming inside eventProfile API",req.query);
let EventId= req.query;
res.header("Access-Control-Allow-Origin", "*");
res.header("Access-Control-Allow-Headers", "X-Requested-With");
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};
   func.getEventDetail(EventId, function (res1) {
     console.log(res1);
         res.send(res1);
  });
});

app.get('/agendaList/:id',function(req,res,err){

  console.log(req.params.id);
console.log("coming inside eventProfile API",req.params.id);
let agendaList = req.params.id;
res.header("Access-Control-Allow-Origin", "*");
res.header("Access-Control-Allow-Headers", "X-Requested-With");
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};
   func.getEventAgenda(agendaList, function (res1) {
     console.log(res1);
         res.send(res1);
  });
});

app.get('/agendaDetail/:id',function(req,res,err){

  console.log(req.params.id);
console.log("coming inside eventProfile API",req.params.id);
let agendaDetail = req.params.id;
res.header("Access-Control-Allow-Origin", "*");
res.header("Access-Control-Allow-Headers", "X-Requested-With");
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};
   func.getAgendaDetails(agendaDetail, function (res1) {
     console.log(res1);
         res.send(res1);
  });
});

app.get('/speakers/:id',function(req,res,err){

console.log("coming inside eventProfile API",req.params.id);
let speakerList = req.params.id;
res.header("Access-Control-Allow-Origin", "*");
res.header("Access-Control-Allow-Headers", "X-Requested-With");
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};
   func.getSpeakers(speakerList, function (res1) {
     console.log(res1);
         res.send(res1);
  });
});

app.get('/sponsors/:id',function(req,res,err){

console.log("coming inside eventProfile API",req.params.id);
let sponsorList = req.params.id;
res.header("Access-Control-Allow-Origin", "*");
res.header("Access-Control-Allow-Headers", "X-Requested-With");
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};
   func.getSponsors(sponsorList, function (res1) {
     console.log(res1);
         res.send(res1);
  });
});

app.get('/sponsordetails/:id',function(req,res,err){

console.log("coming inside eventProfile API",req.params.id);
let sponsorDetails = req.params.id;
res.header("Access-Control-Allow-Origin", "*");
res.header("Access-Control-Allow-Headers", "X-Requested-With");
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};
   func.getSponsorDetails(sponsorDetails, function (res1) {
     console.log(res1);
         res.send(res1);
  });
});

app.get('/contactperson/:id',function(req,res,err){
console.log("coming inside eventProfile API",req.params.id);
let contactPerson = req.params.id;
res.header("Access-Control-Allow-Origin", "*");
res.header("Access-Control-Allow-Headers", "X-Requested-With");
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};
   func.getContactPerson(contactPerson, function (res1) {
     console.log(res1);
         res.send(res1);
  });
});

app.get('/eventform',function(req,res,err){

 console.log("coming inside eventProfile API");
let response = {EventName: req.query.EventName,
      CreatorName:req.query.CreatorName,
    CompanyName:req.query.CompanyName,
  TimeZone:req.query.TimeZone,
  Location:req.query.Location,
  StartDate:req.query.StartDateTime,
  EndDate:req.query.EndDateTime,
  Description:req.query.Description,
  AdId:'353411'};
      console.log(response);
res.header("Access-Control-Allow-Origin", "*");
res.header("Access-Control-Allow-Headers", "X-Requested-With");
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};
   func.getEventFormData(response, function (res1) {
     console.log(res1);
         res.send(res1);
  });
});

app.get('/agendaform',function(req,res,err){

 console.log("coming inside agendaform API");
let response = {AgendaName: req.query.AgendaName,
  Date:req.query.Date,
  Venue:req.query.Venue,
  StartTime:req.query.StartTime,
  EndTime:req.query.EndTime,
  Description:req.query.Description,
  };
console.log(response);
res.header("Access-Control-Allow-Origin", "*");
res.header("Access-Control-Allow-Headers", "X-Requested-With");
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};
   func.getAgendaFormData(response, function (res1) {
     console.log(res1);
         res.send(res1);
  });
});

app.get('/agendaname',function(req,res,err){
  console.log("coming inside agendaName API");
  var agendaName = req.body;
 res.header("Access-Control-Allow-Origin", "*");
 res.header("Access-Control-Allow-Headers", "X-Requested-With");
   res.locals.message = err.message;
   res.locals.error = req.app.get('env') === 'development' ? err : {};
    func.getAgendaName(agendaName, function (res1) {
      console.log(res1);
          res.send(res1);
   });
 });

app.get('/speakerform',function(req,res,err){

 console.log("coming inside speakerform API");
let response = {AgendaName: req.query.AgendaName,
  Name:req.query.Name,
  EmailId:req.query.EmailId,
  Designation:req.query.Designation,
  };
      console.log(response);
res.header("Access-Control-Allow-Origin", "*");
res.header("Access-Control-Allow-Headers", "X-Requested-With");
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};
   func.getSpeakersData(response, function (res1) {
     console.log(res1);
         res.send(res1)
         ;
  });
});

app.get('/contactpersonform',function(req,res,err){

 console.log("coming inside contactpersonform API");
let response = {
  Name:req.query.Name,
  EmailId:req.query.EmailId,
  ContactNumber:req.query.ContactNumber,
  };
      console.log(response);
res.header("Access-Control-Allow-Origin", "*");
res.header("Access-Control-Allow-Headers", "X-Requested-With");
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};
   func.getContactPersonData(response, function (res1) {
     console.log(res1);
         res.send(res1)
         ;
  });
});

app.get('/sponsorform',function(req,res,err){

 console.log("coming inside sponsorform API");
let response = {
  SponsorName: req.query.SponsorName,
  EmailId: req.query.EmailId,
  ContactNumber: req.query.ContactNumber,
  Website: req.query.Website,
  Description: req.query.Description
  };
      console.log(response);
res.header("Access-Control-Allow-Origin", "*");
res.header("Access-Control-Allow-Headers", "X-Requested-With");
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};
   func.getSponsorsData(response, function (res1) {
     console.log(res1);
         res.send(res1);
  });
});

app.get('/addinvitees',function(req,res,err){

 console.log("coming inside seninvite API");
let response = {
  UserEmail: req.query.ReceiverId,
  EventType: req.query.EventType
  };
console.log(response);
res.header("Access-Control-Allow-Origin", "*");
res.header("Access-Control-Allow-Headers", "X-Requested-With");
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};
   func.addInvitees(response, function (res1) {
     console.log(res1);
         res.send(res1);
  });
});

app.get('/sendInvitation',function(req,res,err){

 console.log("coming inside seninvite API");
 let response=req.body;
console.log(response);
res.header("Access-Control-Allow-Origin", "*");
res.header("Access-Control-Allow-Headers", "X-Requested-With");
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};
   func.sendInvitation(response, function (res1) {
     console.log(res1);
         res.send(res1);
  });
});

app.get('/scheduleData',function(req,res,err){

console.log("coming inside Schedule");
let x= {
  AgendaId:req.query.AgendaId};
     console.log(x);
res.header("Access-Control-Allow-Origin", "*");
res.header("Access-Control-Allow-Headers", "X-Requested-With");
 res.locals.message = err.message;
 res.locals.error = req.app.get('env') === 'development' ? err : {};
  func.getScheduleDetails(x, function (res1) {
    console.log(res1);
        res.send(res1);
 });
});

app.get('/schedule',function(req,res,err){

console.log("coming inside Schedule");
let x= req.body;
res.header("Access-Control-Allow-Origin", "*");
res.header("Access-Control-Allow-Headers", "X-Requested-With");
 res.locals.message = err.message;
 res.locals.error = req.app.get('env') === 'development' ? err : {};
  func.getScheduleData(x, function (res1) {
    console.log(res1);
        res.send(res1);
 });
});

app.get('/deleteSchedule',function(req,res,err){

console.log("coming inside Schedule deletion");
let y= {
  AgendaId:req.query.AgendaId};
     console.log(y);
res.header("Access-Control-Allow-Origin", "*");
res.header("Access-Control-Allow-Headers", "X-Requested-With");
 res.locals.message = err.message;
 res.locals.error = req.app.get('env') === 'development' ? err : {};
  func.getScheduleDeletion(y, function (res1) {
    console.log(res1);
        res.send(res1);
 });
});

app.get('/rsvpData',function(req,res,err){

console.log("coming inside RSVP");
let response= {
  RSVPStatus: req.query.RSVPStatus,
  CostCenter: req.query.CostCenter,
  FoodPreference: req.query.FoodPreference,
  TransportDetails: req.query.TransportDetails,
  EventId: req.query.EventId
};
     console.log(response);
res.header("Access-Control-Allow-Origin", "*");
res.header("Access-Control-Allow-Headers", "X-Requested-With");
 res.locals.message = err.message;
 res.locals.error = req.app.get('env') === 'development' ? err : {};
  func.getInviteeResponse(response, function (res1) {
    console.log(res1);
        res.send(res1);
 });
});

app.get('/acceptedInviteeList/:id',function(req,res,err){

 console.log(req.params.id);
console.log("coming inside eventProfile API",req.params.id);
let acceptedInvitee = req.params.id;
res.header("Access-Control-Allow-Origin", "*");
res.header("Access-Control-Allow-Headers", "X-Requested-With");
 res.locals.message = err.message;
 res.locals.error = req.app.get('env') === 'development' ? err : {};
  func.getAcceptedInviteeDetail(acceptedInvitee, function (res1) {
    console.log(res1);
        res.send(res1);
 });
});
app.get('/inviteeList/:id',function(req,res,err){

 console.log(req.params.id);
console.log("coming inside eventProfile API",req.params.id);
let inviteeEvent = req.params.id;
res.header("Access-Control-Allow-Origin", "*");
res.header("Access-Control-Allow-Headers", "X-Requested-With");
 res.locals.message = err.message;
 res.locals.error = req.app.get('env') === 'development' ? err : {};
  func.getInviteeDetail(inviteeEvent, function (res1) {
    console.log(res1);
        res.send(res1);
 });
});

app.get('/declinedInviteeList/:id',function(req,res,err){

 console.log(req.params.id);
console.log("coming inside declined invite API",req.params.id);
let declinedInvitee = req.params.id;
res.header("Access-Control-Allow-Origin", "*");
res.header("Access-Control-Allow-Headers", "X-Requested-With");
 res.locals.message = err.message;
 res.locals.error = req.app.get('env') === 'development' ? err : {};
  func.getDeclinedInviteeDetail(declinedInvitee, function (res1) {
    console.log(res1);
        res.send(res1);
 });
});

app.listen(5050,() =>{
console.log("Server listening");
});

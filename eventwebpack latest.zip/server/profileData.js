var pool = require('./DbConnection/dbConnection');
var sql = require('mssql');
var request = new sql.Request(pool);
var eventId ='';
var loginId = '';

//login
exports.getLogin = function(loginData,callback){
  var q = 'Select * from Login';
 request.query(q, function(err, rows) {
  console.log("coming inside Db function");
     if(err){
         console.log("err in db function",err)
         let response = {
             "status" : "fail",
             "Reason" : "DbIssue",
             "ErrorMessage" : err.toString()
         }
         if(callback){
             callback(response);
         }
     }
     else{
            let response = {
            "status" : "success",
            "DbData": rows.recordset
        }
         if(callback){
            console.log('response');
            callback(response);
        }
     }
});
};

exports.getLoginId = function(x,callback){
  console.log(x.LoginId);
  loginid = x.LoginId;
  console.log(loginid);
  var q = "select * from Login where LoginID='"+x.LoginId+"'";
  request.query(q, function(err, rows) {
   console.log("coming inside loginid function");
      if(err){
          console.log("err in eventdb function",err)
          let response = {
              "status" : "fail",
              "Reason" : "DbIssue",
              "ErrorMessage" : err.toString()
          }
          if(callback){
              callback(response);
          }
      }
      else{
              let response = {
              "status" : "success",
              "DbData": rows.recordset
          }
           if(callback){
              console.log('response');
              callback(response);
                    }
                }
        });
};

exports.getProfile = function(profileData,callback){
 var q = "SELECT * FROM Profile  WHERE UserEmail IN(SELECT l.UserEmail FROM Login l WHERE LoginID='"+loginid+"') ";
request.query(q, function(err, rows) {
 console.log("coming inside Db function");
    if(err){
        console.log("err in db function",err)
        let response = {
            "status" : "fail",
            "Reason" : "DbIssue",
            "ErrorMessage" : err.toString()
        }
        if(callback){
            callback(response);
        }
    }
    else{
            let response = {
            "status" : "success",
            "DbData": rows.recordset
        }
         if(callback){
            console.log('response');
            callback(response);
        }
    }
});
};

exports.getNotifications = function(notifications,callback){
  var q = "SELECT distinct NotificationDescription FROM Notifications n,CreateEvent c WHERE c.EventId IN ( SELECT EventId FROM Notifications WHERE ReceiverId = (select UserEmail from Login where LoginID='"+loginid+"' ) and Status=0)";
 request.query(q, function(err, rows) {
  console.log("coming inside Db function");
     if(err){
         console.log("err in db function",err)
         let response = {
             "status" : "fail",
             "Reason" : "DbIssue",
             "ErrorMessage" : err.toString()
         }
         if(callback){
             callback(response);
         }
     }
     else{
             let response = {
             "status" : "success",
             "DbData": rows.recordset
         }
          if(callback){
             console.log('response');
             callback(response);
         }
     }
});
};

//get details
exports.getEvents = function(EventId,callback){
  var q1 = "SELECT * FROM CreateEvent WHERE EventId IN ( SELECT EventId FROM Invitees WHERE UserEmail = (select UserEmail from Login where LoginID='"+loginid+"' ) and Status='true')";
  request.query(q1, function(err, rows) {
   console.log("coming inside eventdb function");
      if(err){
          console.log("err in eventdb function",err)
          let response = {
              "status" : "fail",
              "Reason" : "DbIssue",
              "ErrorMessage" : err.toString()
          }
          if(callback){
              callback(response);
          }
      }
      else{
              let response = {
              "status" : "success",
              "DbData": rows.recordset
          }
           if(callback){
              console.log('response');
              callback(response);
          }
      }
 });
};

exports.getEventDetail = function(EventId,callback){
  var q2 = "SELECT * FROM CreateEvent where UserEmail=(select UserEmail from Login where LoginID='"+loginid+"')";
 request.query(q2, function(err, rows) {
  console.log("coming inside Db function");
     if(err){
         console.log("err in db function",err)
         let response = {
             "status" : "fail",
             "Reason" : "DbIssue",
             "ErrorMessage" : err.toString()
         }
         if(callback){
             callback(response);
         }
     }
     else{
             let response = {
             "status" : "success",
             "DbData": rows.recordset
         }
          if(callback){
             console.log('response');
             callback(response);
         }
     }
});
};

exports.getEventAgenda = function(EventId,callback){

  var q = 'select * from Agenda where EventId='+ EventId;
  console.log(EventId);
 request.query(q, function(err, rows) {
  console.log("coming inside Db function");
     if(err){
         console.log("err in db function",err)
         let response = {
             "status" : "fail",
             "Reason" : "DbIssue",
             "ErrorMessage" : err.toString()
         }
         if(callback){
             callback(response);
         }
     }
     else{
             let response = {
             "status" : "success",
             "DbData": rows.recordset
         }
          if(callback){
             console.log('response');
             callback(response);
         }
     }
});
};

exports.getAgendaDetails = function(AgendaId,callback){

  var q = 'select * from Agenda where AgendaId='+ AgendaId;
  console.log(AgendaId);
 request.query(q, function(err, rows) {
  console.log("coming inside Db function");
     if(err){
         console.log("err in db function",err)
         let response = {
             "status" : "fail",
             "Reason" : "DbIssue",
             "ErrorMessage" : err.toString()
         }
         if(callback){
             callback(response);
         }
     }
     else{
             let response = {
             "status" : "success",
             "DbData": rows.recordset
         }
          if(callback){
             console.log('response');
             callback(response);
         }
     }
});
};

exports.getSpeakers = function(EventId,callback){

  var q = 'select * from Speakers where EventId =' + EventId;
 request.query(q, function(err, rows) {
  console.log("coming inside Db function");
     if(err){
         console.log("err in db function",err)
         let response = {
             "status" : "fail",
             "Reason" : "DbIssue",
             "ErrorMessage" : err.toString()
         }
         if(callback){
             callback(response);
         }
     }
     else{
             let response = {
             "status" : "success",
             "DbData": rows.recordset
         }
          if(callback){
             console.log('response');
             callback(response);
         }
     }
});
};

exports.getSponsors = function(EventId,callback){

  var q = 'select * from Sponsors where EventId='+ EventId;
 request.query(q, function(err, rows) {
  console.log("coming inside Db function");
     if(err){
         console.log("err in db function",err)
         let response = {
             "status" : "fail",
             "Reason" : "DbIssue",
             "ErrorMessage" : err.toString()
         }
         if(callback){
             callback(response);
         }
     }
     else{
             let response = {
             "status" : "success",
             "DbData": rows.recordset
         }
          if(callback){
             console.log('response');
             callback(response);
         }
     }
});
};

exports.getSponsorDetails = function(SponsorId,callback){
var q = 'select * from Sponsors where SponsorsId ='+ SponsorId;

 request.query(q, function(err, rows) {
  console.log("coming inside Db function");
     if(err){
         console.log("err in db function",err)
         let response = {
             "status" : "fail",
             "Reason" : "DbIssue",
             "ErrorMessage" : err.toString()
         }
         if(callback){
             callback(response);
         }
     }
     else{
             let response = {
             "status" : "success",
             "DbData": rows.recordset
         }
          if(callback){
             console.log('response');
             callback(response);
         }
     }
});
};

exports.getContactPerson = function(EventId,callback){

  var q = 'select * from ContactPerson where EventId=' + EventId;
 request.query(q, function(err, rows) {
  console.log("coming inside Db function");
     if(err){
         console.log("err in db function",err)
         let response = {
             "status" : "fail",
             "Reason" : "DbIssue",
             "ErrorMessage" : err.toString()
         }
         if(callback){
             callback(response);
         }
     }
     else{
             let response = {
             "status" : "success",
             "DbData": rows.recordset
         }
          if(callback){
             console.log('response');
             callback(response);
         }
     }
});
};

//post data on server
exports.getEventFormData = function(response,callback){
console.log(response.EndDate);
  var q = "Insert into CreateEvent(UserEmail,EventName,CreatorName,CompanyName,Location,StartDate,EndDate,TimeZone,Description) values ((select UserEmail from Login where LoginID='"+loginid+"'),'"+response.EventName+"','"+response.CreatorName+"','"+response.CompanyName+"','"+response.Location+"','"+response.StartDate+"','"+response.EndDate+"','"+response.TimeZone+"','"+response.Description+"')";
 request.query(q, function(err, rows1) {
  console.log("coming inside Db function");
     if(err){
         console.log("err in db function",err)
         let response = {
             "status" : "fail",
             "Reason" : "DbIssue",
             "ErrorMessage" : err.toString()
         }
         if(callback){
             callback(response);
         }
     }
     else{
          if(callback){
             request.query("select EventId from CreateEvent where EventName='"+response.EventName+"'",function(err,rows2){
               if(err){
                   console.log("err in db2 function",err)
                   let response = {
                       "status" : "fail",
                       "Reason" : "DbIssue",
                       "ErrorMessage" : err.toString()
                   }
                   if(callback){
                       callback(response);
                   }
               }
               if(callback){
                  console.log('data showing successfully');
                  Id = rows2.recordset[0];
                  eventId = Object.values(Id);
                  console.log(Object.values(eventId));
                  return callback(eventId);
              }
            });
         }
     }
});
};
exports.getAgendaFormData = function(response,callback){
var q = "Insert into Agenda(EventId,AgendaName,Date,StartTime,EndTime,Venue,Description) values ('"+eventId+"','"+response.AgendaName+"','"+response.Date+"','"+response.StartTime+"','"+response.EndTime+"','"+response.Venue+"','"+response.Description+"')";
 request.query(q, function(err, rows) {
  console.log("coming inside Db function");
     if(err){
         console.log("err in db function",err)
         let response = {
             "status" : "fail",
             "Reason" : "DbIssue",
             "ErrorMessage" : err.toString()
         }
         if(callback){
             callback(response);
         }
     }
     else{
             let response = {
             "status" : "success",
             "DbData": rows.recordset
         }
          if(callback){
             console.log('data of agenda added successfully');
              callback(response);
         }
     }
});
};

exports.getAgendaName = function(even,callback){
  console.log(eventId);
var q = 'select AgendaName from Agenda where EventId ='+ eventId;

 request.query(q, function(err, rows) {
  console.log("coming inside Db1 function");
     if(err){
         console.log("err in db function",err)
         let response = {
             "status" : "fail",
             "Reason" : "DbIssue",
             "ErrorMessage" : err.toString()
         }
         if(callback){
             callback(response);
         }
     }
     else{
             let response = {
             "status" : "success",
             "DbData": rows.recordset
         }
          if(callback){
             console.log('response');
             callback(response);
         }
     }
});
};

exports.getSpeakersData = function(response,callback){
  console.log(response.Name);
var q = "insert into Speakers(AgendaId,Name,EmailId,Designation,EventId) values ((select AgendaId from Agenda where AgendaName='"+response.AgendaName+"'),'"+response.Name+"','"+response.EmailId+"','"+response.Designation+"',(select EventId from Agenda where AgendaName='"+response.AgendaName+"'))";
 request.query(q, function(err, rows) {
  console.log("coming inside Db function");
     if(err){
         console.log("err in db function",err)
         let response = {
             "status" : "fail",
             "Reason" : "DbIssue",
             "ErrorMessage" : err.toString()
         }
         if(callback){
             callback(response);
         }
     }
     else{
             let response = {
             "status" : "success",
             "DbData": rows.recordset
         }
          if(callback){
             console.log('data added successfully');
             callback(response);
         }
     }
});
};

exports.getContactPersonData = function(response,callback){
var q = "insert into ContactPerson(EventId,Name,EmailId,ContactNumber) values ('"+eventId+"','"+response.Name+"','"+response.EmailId+"','"+response.ContactNumber+"')";
 request.query(q, function(err, rows) {
  console.log("coming inside Db function");
     if(err){
         console.log("err in db function",err)
         let response = {
             "status" : "fail",
             "Reason" : "DbIssue",
             "ErrorMessage" : err.toString()
         }
         if(callback){
             callback(response);
         }
     }
     else{
             let response = {
             "status" : "success",
             "DbData": rows.recordset
         }
          if(callback){
             console.log('data in contactPerson added successfully');
             callback(response);
         }
     }
});
};

exports.getSponsorsData = function(response,callback){
var q = "insert into Sponsors(EventId,SponsorName,Website,EmailId,ContactNumber,Description) values ('"+eventId+"','"+response.SponsorName+"','"+response.Website+"','"+response.EmailId+"','"+response.ContactNumber+"','"+response.Description+"')";
 request.query(q, function(err, rows) {
  console.log("coming inside Db function");
     if(err){
         console.log("err in db function",err)
         let response = {
             "status" : "fail",
             "Reason" : "DbIssue",
             "ErrorMessage" : err.toString()
         }
         if(callback){
             callback(response);
         }
     }
     else{
             let response = {
             "status" : "success",
             "DbData": rows.recordset
         }
          if(callback){
             console.log('data in sponsor added successfully');
             callback(response);
         }
     }
});
};

exports.addInvitees = function(response,callback){
  var q = "Insert into Invitees(EventId, EventType, UserEmail,Status,SenderId) values ('"+eventId+"','"+response.EventType+"','"+response.UserEmail+"','false',(select UserEmail from Login where LoginId='"+loginid+"'))";
  request.query(q, function(err, rows) {
   console.log("coming inside Db function");
      if(err){
          console.log("err in db function",err)
          let response = {
              "status" : "fail",
              "Reason" : "DbIssue",
              "ErrorMessage" : err.toString()
          }
          if(callback){
              callback(response);
          }
      }
      else{
              let response = {
              "status" : "success",
              "DbData": rows.recordset
          }
           if(callback){
              console.log('data in Invitees added successfully');
              callback(response);
          }
      }
 });
}

exports.sendInvitation = function(response,callback){
var q = "Update Invitees set Status='true' where EventId='"+eventId+"'";
 request.query(q, function(err, rows) {
  console.log("coming inside Db function");
     if(err){
         console.log("err in db function",err)
         let response = {
             "status" : "fail",
             "Reason" : "DbIssue",
             "ErrorMessage" : err.toString()
         }
         if(callback){
             callback(response);
         }
     }
     else{
             let response = {
             "status" : "success",
             "DbData": rows.recordset
         }
          if(callback){
             console.log('data in Notifications added successfully');
             callback(response);
         }
     }
});
};

exports.getInviteeResponse = function(response,callback){
var q = "Insert into RSVP(RSVPStatus,CostCenter,FoodPreference,TransportDetails,InviteeEmail,EventId) values ('"+response.RSVPStatus+"','"+response.CostCenter+"','"+response.FoodPreference+"','"+response.TransportDetails+"',(select UserEmail from Login where LoginId='"+loginid+"'),'"+response.EventId+"')";
 request.query(q, function(err, rows) {
  console.log("coming inside Db function");
     if(err){
         console.log("err in db function",err)
         let response = {
             "status" : "fail",
             "Reason" : "DbIssue",
             "ErrorMessage" : err.toString()
         }
         if(callback){
             callback(response);
         }
     }
     else{
             let response = {
             "status" : "success",
             "DbData": rows.recordset
         }
          if(callback){
             console.log('data in Notifications added successfully');
             callback(response);
         }
     }
});
};

exports.getScheduleDetails = function(x,callback){

 var q = "insert into Schedule(AgendaId,AgendaName,StartTime,EndTime,Date,Venue,EventId,UserEmail) values('"+x.AgendaId+"',(select AgendaName from Agenda where AgendaId='"+x.AgendaId+"'),(select StartTime from Agenda where AgendaId='"+x.AgendaId+"'),(select EndTime from Agenda where AgendaId='"+x.AgendaId+"'),(select Date from Agenda where AgendaId='"+x.AgendaId+"'),(select Venue from Agenda where AgendaId='"+x.AgendaId+"'),(select EventId from Agenda where AgendaId='"+x.AgendaId+"'),(select UserEmail from Login where LoginId='"+loginid+"'))";
 console.log(x.AgendaId);
request.query(q, function(err, rows) {
 console.log("coming inside Db function");
    if(err){
        console.log("err in db function",err)
        let response = {
            "status" : "fail",
            "Reason" : "DbIssue",
            "ErrorMessage" : err.toString()
        }
        if(callback){
            callback(response);
        }
    }
    else{
            let response = {
            "status" : "success",
            "DbData": rows.recordset
        }
         if(callback){
            console.log('data added to schedule');
            callback(response);
        }
    }
});
};

exports.getScheduleData = function(x,callback){
 var q = "select * from Schedule where UserEmail=(select UserEmail from Login where LoginId='"+loginid+"')";
request.query(q, function(err, rows) {
 console.log("coming inside schedule function");
    if(err){
        console.log("err in db function",err)
        let response = {
            "status" : "fail",
            "Reason" : "DbIssue",
            "ErrorMessage" : err.toString()
        }
        if(callback){
            callback(response);
        }
    }
    else{
            let response = {
            "status" : "success",
            "DbData": rows.recordset
        }
         if(callback){
            console.log('data shown');
            callback(response);
        }
    }
});
};

exports.getScheduleDeletion = function(y,callback){
 var q = "delete from Schedule where AgendaId='"+y.AgendaId+"'";
 console.log(y.AgendaId);
request.query(q, function(err, rows) {
 console.log("coming inside Db function");
    if(err){
        console.log("err in db function",err)
        let response = {
            "status" : "fail",
            "Reason" : "DbIssue",
            "ErrorMessage" : err.toString()
        }
        if(callback){
            callback(response);
        }
    }
    else{
            let response = {
            "status" : "success",
            "DbData": rows.recordset
        }
         if(callback){
            console.log('data Removed from schedule');
            callback(response);
        }
    }
});
};

exports.getAcceptedInviteeDetail = function(acceptedInvitee,callback){
 var q1 = "Select p.FirstName, p.LastName, r.InviteeEmail, p.MobileNumber from Profile p, RSVP r where r.EventId = '"+acceptedInvitee+"' AND p.UserEmail = r.InviteeEmail AND r.RSVPStatus = 'accept' ";

 request.query(q1, function(err, rows) {
  console.log("coming inside acceptedInvitee function");
     if(err){
         console.log("err in acceptedInvitee function",err)
         let response = {
             "status" : "fail",
             "Reason" : "DbIssue",
             "ErrorMessage" : err.toString()
         }
         if(callback){
             callback(response);
         }
     }
     else{
             let response = {
             "status" : "success",
             "DbData": rows.recordset
         }
          if(callback){
             console.log('response');
             callback(response);
         }
     }
});
};

exports.getDeclinedInviteeDetail = function(declinedInvitee,callback){
 var q1 = "Select p.FirstName, p.LastName, r.InviteeEmail, p.MobileNumber from Profile p, RSVP r where r.EventId = '"+declinedInvitee+"' AND p.UserEmail = r.InviteeEmail  AND r.RSVPStatus = 'decline'";
 request.query(q1, function(err, rows) {
  console.log("coming inside declinedInvitee function");
     if(err){
         console.log("err in declinedInvitee function",err)
         let response = {
             "status" : "fail",
             "Reason" : "DbIssue",
             "ErrorMessage" : err.toString()
         }
         if(callback){
             callback(response);
         }
     }
     else{
             let response = {
             "status" : "success",
             "DbData": rows.recordset
         }
          if(callback){
             console.log('response');
             callback(response);
         }
     }
});
};

exports.getInviteeDetail = function(inviteeEvent,callback){
 var q1 = "Select p.FirstName, p.LastName, r.InviteeEmail, p.MobileNumber from Profile p, RSVP r where r.EventId = '"+inviteeEvent+"' AND p.UserEmail = r.InviteeEmail ";;
 request.query(q1, function(err, rows) {
  console.log("coming inside InviteeList function");
     if(err){
         console.log("err in InviteeList function",err)
         let response = {
             "status" : "fail",
             "Reason" : "DbIssue",
             "ErrorMessage" : err.toString()
         }
         if(callback){
             callback(response);
         }
     }
     else{
             let response = {
             "status" : "success",
             "DbData": rows.recordset
         }
          if(callback){
             console.log('response');
             callback(response);
         }
     }
});
};
//update data from server
// exports.getEvents = function(createdeventData,callback){
//   var q1 = "SELECT * FROM CreateEvent where EventId=(select UserEmail from Login where LoginID='"+loginid+"')";
//   request.query(q1, function(err, rows) {
//    console.log("coming inside eventdb function");
//       if(err){
//           console.log("err in eventdb function",err)
//           let response = {
//               "status" : "fail",
//               "Reason" : "DbIssue",
//               "ErrorMessage" : err.toString()
//           }
//           if(callback){
//               callback(response);
//           }
//       }
//       else{
//               let response = {
//               "status" : "success",
//               "DbData": rows.recordset
//           }
//            if(callback){
//               console.log('response');
//               callback(response);
//           }
//       }
//  });
// };
